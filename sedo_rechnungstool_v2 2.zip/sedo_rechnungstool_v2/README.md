# SEDO Rechnungstool · v1.0 beta 3.21.0

Lokales Rechnungstool für ZUGFeRD-E-Rechnungen. **Alles läuft auf diesem
Rechner** – Server, Datenbank, PDFs, Spracherkennung. Nur der Text des
KI-Assistenten geht an Claude (niemals Kunden-/Objektdaten, kein Audio).

## Starten (empfohlen: Desktop-Modus)

**Mac:** `SEDO.app` doppelklicken → SEDO öffnet sich als eigenes Programmfenster.
Tipp: `SEDO.app` ins Dock ziehen.

**Windows:** Einmalig `DESKTOP_VERKNUEPFUNG_ERSTELLEN.bat` doppelklicken –
danach liegt „SEDO Rechnungstool“ mit Logo auf dem Desktop und startet das
Programmfenster (über `SEDO.vbs`).

Beim **allerersten Start** richtet sich SEDO selbst ein (Pakete installieren,
kann einige Minuten dauern) und zeigt **einmalig das Admin-Passwort** an –
bitte sofort notieren!

- Benutzer: `admin`
- Passwort: wird beim ersten Start einmalig angezeigt
  (ändern/zurücksetzen: `python manage.py changepassword admin`)

## Beenden

Das Fenster schließen beendet nur die Ansicht – der Server läuft weiter
(nächster Start ist dadurch sofort da). Komplett beenden:
`SEDO_BEENDEN.command` (Mac) bzw. `SEDO_BEENDEN.bat` (Windows).

## Klassischer Start (Fallback / Fehlersuche)

`START_HIER.command` (Mac) bzw. `START_WINDOWS.bat` (Windows) doppelklicken –
zeigt alle Meldungen sichtbar an. Danach im Browser: http://127.0.0.1:8000

## Erste Schritte nach der Installation

1. `.env` nach dem Muster von `.env.example` anlegen (Produktivbetrieb).
2. Einstellungen → **KI-Assistent**: Claude-API-Key eintragen.
3. Erstes Diktat lädt das Whisper-Sprachmodell (~460 MB) einmalig herunter.
4. Vor dem ersten ARP-/Aareon-Echtlauf: Checkliste in `MEMORY_SEDO.md` beachten
   (ARP Seller-ID, Empfänger-ID, BT-130/BT-154-Abgleich mit Tönnies).

Details zu allen Änderungen: `AENDERUNGSBERICHT_v1_0_beta_3_21_0.md`


## Komplettpaket (echtes Desktop-Programm, seit v2.2)

Alternativ zum klassischen Starter gibt es SEDO als gebündeltes Programm mit
eigenem Fenster – ohne Browser und ohne Python-Installation:

- **Mac:** `build_mac.command` doppelklicken → `dist/SEDO Rechnungstool.app`
  (bei Bedarf in „Programme“ ziehen).
- **Windows:** Ordner auf einen Windows-Rechner kopieren (z. B. Parallels),
  Python 3.12+ von python.org installieren („Add to PATH“ anhaken),
  `BUILD_WINDOWS.bat` doppelklicken → `dist\SEDO Rechnungstool\…exe`.
  Den GANZEN dist-Ordner auf den Zielrechner kopieren.

Wichtig zu wissen:
- Das Komplettpaket speichert seine Daten im **Benutzerordner**
  (Mac: `~/Library/Application Support/SEDO`, Windows: `%APPDATA%\SEDO`) –
  getrennt vom Projektordner des klassischen Starters. Bestehende Daten
  übernehmen: die Ordner `data/` und `media/` dorthin kopieren (bei
  gestopptem Programm).
- Beim allerersten Start zeigt das Fenster einmalig das Admin-Zufallspasswort.
- Das **lokale Whisper-Diktat ist im Komplettpaket nicht enthalten**
  (bewusst, >200 MB) – wer diktieren will, nutzt den klassischen Starter.
  Alle übrigen KI-Funktionen (Generator, Magic-Tone, KI-Check) funktionieren.
