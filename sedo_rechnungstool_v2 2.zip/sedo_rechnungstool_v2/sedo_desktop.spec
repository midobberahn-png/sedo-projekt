# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller-Spec: SEDO als gebündeltes Desktop-Programm (Mac + Windows).

Build:  pyinstaller sedo_desktop.spec   (im Projektordner, venv mit
        requirements_desktop.txt). Ergebnis: dist/SEDO Rechnungstool[.app/.exe]

Bewusst OHNE faster-whisper/ctranslate2: Das lokale Whisper-Diktat bleibt dem
klassischen Starter (SEDO.app/START_HIER) vorbehalten – im Komplettpaket wäre
es >200 MB Ballast und das native Webview hat ohnehin keine Browser-Spracherkennung.
"""
import sys
from PyInstaller.utils.hooks import collect_all, collect_submodules

django_datas, django_binaries, django_hidden = collect_all('django')

hiddenimports = (
    django_hidden
    + collect_submodules('sedo')          # inkl. Migrationen + management.commands
    + ['config.settings', 'config.urls', 'config.wsgi',
       'whitenoise', 'whitenoise.middleware', 'whitenoise.storage',
       'waitress']
)

datas = django_datas + [
    ('sedo/templates', 'sedo/templates'),
    ('sedo/static', 'sedo/static'),
]

a = Analysis(
    ['desktop.py'],
    pathex=[],
    binaries=django_binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=['faster_whisper', 'ctranslate2', 'tokenizers', 'huggingface_hub',
              'tkinter', 'matplotlib', 'scipy', 'IPython', 'pytest'],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='SEDO Rechnungstool',
    debug=False,
    strip=False,
    upx=False,
    console=False,                 # echtes Fensterprogramm, kein Terminal
    icon='SEDO.app/Contents/Resources/sedo.icns' if sys.platform == 'darwin' else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name='SEDO Rechnungstool',
)

if sys.platform == 'darwin':
    app = BUNDLE(
        coll,
        name='SEDO Rechnungstool.app',
        icon='SEDO.app/Contents/Resources/sedo.icns',
        bundle_identifier='de.sedo-magdeburg.rechnungstool',
        info_plist={
            'CFBundleDisplayName': 'SEDO Rechnungstool',
            'CFBundleShortVersionString': '2.2.0',
            'NSHighResolutionCapable': True,
        },
    )
