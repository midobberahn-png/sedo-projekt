@echo off
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist data mkdir data
if not exist media mkdir media
python manage.py makemigrations sedo
python manage.py migrate
python manage.py ensure_admin
echo Öffne im Browser: http://127.0.0.1:8000
echo Login: admin (Passwort wurde beim ersten Start einmalig angezeigt)
echo Passwort aendern: python manage.py changepassword admin
python manage.py runserver 0.0.0.0:8000
pause
