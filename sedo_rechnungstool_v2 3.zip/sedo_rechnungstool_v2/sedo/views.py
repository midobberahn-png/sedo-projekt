from __future__ import annotations
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, date, timedelta
from pathlib import Path
import csv
import json
import zipfile
from email.message import EmailMessage
import pandas as pd
import logging

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.db.models import Sum, Q
from django.db.models.functions import ExtractYear
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.http import FileResponse, JsonResponse
from django.views.decorators.http import require_POST

from .forms import CustomerForm, CustomerObjectForm, InvoiceForm, InvoiceItemFormSet, OfferForm, OfferItemFormSet, BankJsonImportForm, ManualPaymentAssignForm, ManualPaymentForm, CashbookEntryForm, RecurringInvoiceTemplateForm, RecurringInvoiceItemFormSet, ServiceCatalogItemForm
from .models import Customer, CustomerObject, Invoice, InvoiceItem, Offer, Payment, CashbookEntry, AareonMapping, RecurringInvoiceTemplate, RecurringInvoiceItem, AppSetting, AuditLog, ServiceCatalogItem
from .audit import write_audit
from .services import (
    generate_invoice_files, next_number, save_with_unique_number, create_numbered_invoice,
    recalc_invoice, recalc_offer, create_storno,
    WorkflowError, ensure_correction_allowed, ensure_offer_invoicing_allowed,
    mark_invoice_corrected,
    generate_offer_pdf, create_invoice_from_offer, create_email_draft, import_bank_json,
    refresh_invoice_payment_status, generate_dunning_document, next_cashbook_no,
    generate_cashbook_pdf, get_smtp_config, smtp_is_configured, send_email_smtp,
    get_dunning_candidates, send_bulk_dunning, ensure_dunning_allowed,
    fetch_bank_transactions, get_banking_config, banking_is_configured, BankingError,
    get_ai_config, ai_is_configured, generate_offer_from_text, AIError,
    AI_DEFAULT_TEXT_MODEL,
    transcribe_audio, stt_status, TranscriptionUnavailable,
    polish_service_text, generate_cover_letter_text,
    ai_review_positions, check_positions_local,
)
from .services.mail import invoice_email_subject_body

# Interner Logger: breite Exception-Handler (Batch-Läufe, KI-Endpoints) melden
# dem Nutzer eine freundliche Meldung, protokollieren den echten Fehler aber hier.
logger = logging.getLogger('sedo')

# Standard-Zahlungsziel (Tage), wenn beim Kunden nichts hinterlegt ist.
DEFAULT_PAYMENT_DAYS = 14
# Obergrenzen für Listen-/Importansichten.
MAX_OPEN_ITEMS = 500
MAX_PAYMENTS_LIST = 300
MAX_AI_REQUEST_BYTES = 100_000


@login_required
def global_search_api(request):
    """JSON-Endpoint der globalen Suche (v2.1): Kunden, Rechnungen, Angebote, Objekte.

    Liefert gruppierte Treffer für das Suchfeld in der Sidebar. Bewusst kleine
    Limits je Gruppe – die Suche ist ein Sprungbrett, keine Listenansicht.
    """
    q = (request.GET.get('q') or '').strip()
    if len(q) < 2:
        return JsonResponse({'ok': True, 'results': []})
    results = []
    for c in Customer.objects.filter(
            Q(name__icontains=q) | Q(name2__icontains=q) | Q(customer_no__icontains=q))[:4]:
        results.append({
            'gruppe': 'Kunden', 'titel': c.name,
            'sub': ' · '.join(x for x in [c.customer_no, f'{c.postcode} {c.city}'.strip()] if x),
            'badge': '', 'url': reverse('sedo:customer_detail', args=[c.pk]),
        })
    for inv in (Invoice.objects.filter(Q(number__icontains=q) | Q(customer__name__icontains=q))
                .select_related('customer').order_by('-issue_date')[:5]):
        results.append({
            'gruppe': 'Rechnungen', 'titel': inv.number,
            'sub': f'{inv.customer.name} · {inv.gross_total} €',
            'badge': inv.get_status_display(),
            'url': reverse('sedo:invoice_detail', args=[inv.pk]),
        })
    for off in (Offer.objects.filter(Q(number__icontains=q) | Q(customer__name__icontains=q))
                .select_related('customer').order_by('-issue_date')[:4]):
        results.append({
            'gruppe': 'Angebote', 'titel': off.number,
            'sub': f'{off.customer.name} · {off.gross_total} €',
            'badge': off.get_status_display(),
            'url': reverse('sedo:offer_detail', args=[off.pk]),
        })
    for obj in (CustomerObject.objects.filter(
            Q(name__icontains=q) | Q(street__icontains=q) | Q(city__icontains=q))
            .select_related('customer')[:4]):
        results.append({
            'gruppe': 'Objekte', 'titel': obj.name,
            'sub': ' · '.join(x for x in [obj.customer.name, f'{obj.postcode} {obj.city}'.strip()] if x),
            'badge': '', 'url': reverse('sedo:customer_detail', args=[obj.customer_id]),
        })
    return JsonResponse({'ok': True, 'results': results})


@login_required
def customer_data_api(request, pk):
    """JSON-Endpoint: Kundendaten + Objekte für AJAX-Autobefüllung im Rechnungsformular."""
    customer = get_object_or_404(Customer, pk=pk)
    return JsonResponse({
        'id': customer.pk,
        'salutation': customer.salutation or '',
        'customer_no': customer.customer_no or '',
        'customer_type': customer.customer_type or 'einmalig',
        'name': customer.name or '',
        'name2': customer.name2 or '',
        'contact_person': customer.contact_person or '',
        'phone': customer.phone or '',
        'email': customer.email or '',
        'street': customer.street or '',
        'postcode': customer.postcode or '',
        'city': customer.city or '',
        'country': customer.country or 'DE',
        'payment_days': customer.payment_days,
        'objects': [
            {
                'id': obj.pk,
                'name': obj.name,
                'street': obj.street or '',
                'postcode': obj.postcode or '',
                'city': obj.city or '',
                'country': obj.country or 'DE',
            }
            for obj in customer.customer_objects.order_by('name')
        ],
    })


def _sum_decimal(queryset, field: str) -> Decimal:
    """Summe eines DecimalField als saubere Decimal mit 2 Nachkommastellen.

    SQLite liefert bei ``Sum()`` über ein DecimalField einen Float zurück
    (z. B. 5274.7000000000). Diese Umwandlung sorgt für eine korrekte Anzeige.
    """
    total = queryset.aggregate(s=Sum(field))['s'] or Decimal('0.00')
    return Decimal(str(total)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def _norm(v):
    if v is None:
        return ''
    if isinstance(v, float) and pd.isna(v):
        return ''
    return str(v).strip()


def _pick(row, *names):
    lowered = {str(k).strip().lower(): v for k, v in row.items()}
    for name in names:
        key = name.lower()
        if key in lowered:
            return _norm(lowered[key])
    # fuzzy contains
    for key, val in lowered.items():
        for name in names:
            if name.lower() in key:
                return _norm(val)
    return ''


def _pick_customer_name(row):
    """Pick a customer name without accidentally using customer number columns."""
    lowered = {str(k).strip().lower(): v for k, v in row.items()}
    exact_candidates = ['name / firma', 'firma', 'kundenname', 'kunde name', 'name', 'suchname']
    for key in exact_candidates:
        if key in lowered:
            val = _norm(lowered[key])
            if val:
                return val
    for key, val in lowered.items():
        k = key.lower()
        if any(block in k for block in ['kundennr', 'kunden-nr', 'kundennummer', 'kunden nr', 'kd-nr', 'kdnr', 'nummer', 'nr.', 'id']):
            continue
        if any(token in k for token in ['firma', 'kunde', 'name', 'suchname']):
            val = _norm(val)
            if val:
                return val
    return ''


def _fill_customer_initial(form, customer):
    if not customer:
        return
    for field in ['salutation','customer_no','customer_type','name','name2','contact_person','phone','email','street','postcode','city','country']:
        if field in form.fields:
            form.initial[field] = getattr(customer, field, '')


def _fill_object_initial(form, obj):
    if not obj:
        return
    mapping = {
        'object_name': 'name',
        'object_street': 'street',
        'object_postcode': 'postcode',
        'object_city': 'city',
        'object_country': 'country',
    }
    for field, attr in mapping.items():
        if field in form.fields:
            form.initial[field] = getattr(obj, attr, '')


def _customer_from_invoice_form(form):
    customer = form.cleaned_data.get('customer')
    if customer:
        return customer
    name = (form.cleaned_data.get('name') or '').strip()
    if not name:
        return None
    return Customer.objects.create(
        salutation=form.cleaned_data.get('salutation') or '',
        customer_no=form.cleaned_data.get('customer_no') or '',
        customer_type=form.cleaned_data.get('customer_type') or 'einmalig',
        name=name,
        name2=form.cleaned_data.get('name2') or '',
        contact_person=form.cleaned_data.get('contact_person') or '',
        phone=form.cleaned_data.get('phone') or '',
        email=form.cleaned_data.get('email') or '',
        street=form.cleaned_data.get('street') or '',
        postcode=form.cleaned_data.get('postcode') or '',
        city=form.cleaned_data.get('city') or '',
        country=form.cleaned_data.get('country') or 'DE',
        payment_days=form.cleaned_data.get('payment_days') or 14,
    )


def _object_from_invoice_form(form, customer):
    obj = form.cleaned_data.get('obj')
    if obj:
        return obj
    object_name = (form.cleaned_data.get('object_name') or '').strip()
    if not object_name or not customer:
        return None
    return CustomerObject.objects.create(
        customer=customer,
        name=object_name,
        street=form.cleaned_data.get('object_street') or '',
        postcode=form.cleaned_data.get('object_postcode') or '',
        city=form.cleaned_data.get('object_city') or '',
        country=form.cleaned_data.get('object_country') or 'DE',
    )


def _preview_from_forms(form, formset, title='Entwurfsansicht'):
    items = []
    net = Decimal('0.00')
    for item_form in formset.forms:
        if not item_form.cleaned_data or item_form.cleaned_data.get('DELETE'):
            continue
        desc = item_form.cleaned_data.get('description') or ''
        if not desc:
            continue
        qty = item_form.cleaned_data.get('quantity') or Decimal('0.00')
        price = item_form.cleaned_data.get('unit_price') or Decimal('0.00')
        line_total = (qty * price).quantize(Decimal('0.01'))
        net += line_total
        items.append({
            'description': desc,
            'long_text': item_form.cleaned_data.get('long_text') or '',
            'quantity': qty,
            'unit': item_form.cleaned_data.get('unit') or '',
            'unit_price': price,
            'line_total': line_total,
            'article_no': item_form.cleaned_data.get('article_no') or '',
        })
    vat_rate = form.cleaned_data.get('vat_rate') or Decimal('19.00')
    vat = (net * vat_rate / Decimal('100')).quantize(Decimal('0.01'))
    return {
        'title': title,
        'customer': form.cleaned_data.get('customer'),
        'manual_customer': {k: form.cleaned_data.get(k) for k in ['salutation','customer_no','name','name2','contact_person','phone','email','street','postcode','city','country']},
        'obj': form.cleaned_data.get('obj'),
        'manual_object': {k: form.cleaned_data.get(k) for k in ['object_name','object_street','object_postcode','object_city','object_country']},
        'issue_date': form.cleaned_data.get('issue_date'),
        'period_start': form.cleaned_data.get('period_start'),
        'period_end': form.cleaned_data.get('period_end'),
        'items': items,
        'net': net.quantize(Decimal('0.01')),
        'vat_rate': vat_rate,
        'vat': vat,
        'gross': (net + vat).quantize(Decimal('0.01')),
        'note': form.cleaned_data.get('note') if 'note' in form.cleaned_data else '',
    }


def _create_invoice_email_file(invoice: Invoice):
    """Erzeugt eine .eml-Datei zur Rechnung und gibt den Pfad zurück."""
    generate_invoice_files(invoice)
    recipient = invoice.customer.email or ''
    if not recipient:
        return None
    subject, body = invoice_email_subject_body(invoice)
    attachment = invoice.zugferd_file.path if invoice.zugferd_file else None
    out_dir = Path(settings.MEDIA_ROOT) / 'emails' / invoice.number
    return create_email_draft(recipient, subject, body, Path(attachment) if attachment else None, out_dir, f'{invoice.number}_email')


def _normalize_item_positions(items) -> None:
    """Setzt fortlaufende Positionsnummern (1..n) und speichert nur Änderungen."""
    for idx, item in enumerate(items, start=1):
        if item.position != idx:
            item.position = idx
            item.save(update_fields=['position', 'updated_at'])


def _create_recurring_template_from_invoice(inv: Invoice, title: str | None = None):
    """Speichert eine erzeugte Rechnung als Abo-/Monatsrechnungsvorlage."""
    tmpl = RecurringInvoiceTemplate.objects.create(
        customer=inv.customer,
        obj=inv.obj,
        title=title or f'Monatsrechnung {inv.customer.name}' + (f' · {inv.obj.name}' if inv.obj else ''),
        status='active',
        vat_rate=inv.vat_rate,
        payment_days=(inv.due_date - inv.issue_date).days if inv.due_date else (inv.customer.payment_days or 14),
        note=inv.note or '',
    )
    for idx, item in enumerate(inv.items.all(), start=1):
        RecurringInvoiceItem.objects.create(
            template=tmpl,
            position=idx,
            description=item.description,
            long_text=item.long_text,
            quantity=item.quantity,
            unit=item.unit,
            unit_price=item.unit_price,
            article_no=item.article_no,
        )
    return tmpl


def _invoice_items_initial_from_invoice(source: Invoice):
    return [{
        'description': item.description,
        'long_text': item.long_text,
        'quantity': item.quantity,
        'unit': item.unit,
        'unit_price': item.unit_price,
        'article_no': item.article_no,
        'leistungsart_id': item.leistungsart_id,
        'leistungsart_text': item.leistungsart_text,
    } for item in source.items.all()]



@login_required
@require_POST
def ai_generate_offer(request):
    """KI-Assistent: grobe Ansage in einen vollständigen Angebotsentwurf umwandeln.

    Datenschutz: Es wird ausschließlich der diktierte Text der Leistungs-
    beschreibung an Claude übertragen – keine Kunden- oder Objektdaten.
    Nebenwirkung: neue Leistungen werden in den Leistungskatalog übernommen.
    """
    if not ai_is_configured():
        return JsonResponse({'ok': False, 'error': 'Kein Claude-API-Key hinterlegt. Bitte unter Einstellungen → KI-Assistent eintragen.'}, status=400)
    if len(request.body) > MAX_AI_REQUEST_BYTES:
        return JsonResponse({'ok': False, 'error': 'Der Text ist zu lang. Bitte kürzen.'}, status=400)
    try:
        data = json.loads(request.body.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({'ok': False, 'error': 'Ungültige Anfrage.'}, status=400)
    text = (data.get('text') or '').strip() if isinstance(data, dict) else ''
    if len(text) < 5:
        return JsonResponse({'ok': False, 'error': 'Bitte zuerst diktieren oder einen Text eingeben.'}, status=400)
    try:
        result = generate_offer_from_text(text)
    except AIError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=502)
    except Exception:
        logger.exception('KI-Angebotsentwurf fehlgeschlagen')
        return JsonResponse({'ok': False, 'error': 'Unerwarteter Fehler bei der KI-Auswertung. Bitte erneut versuchen.'}, status=500)
    write_audit(request, 'generate', object_type='KI', object_repr='Angebotsentwurf',
                message=f"KI-Assistent: {len(result['positionen'])} Position(en) erzeugt" +
                        (f" · {result['katalog_info']}" if result.get('katalog_info') else ''))
    return JsonResponse({'ok': True, 'positionen': result['positionen'],
                         'hinweise': result['hinweise'], 'annahmen': result['annahmen'],
                         'katalog_info': result.get('katalog_info', '')})


@login_required
@require_POST
def ai_transcribe(request):
    """Lokale Whisper-Transkription: Audio-Diktat → deutscher Text.

    Datenschutz: Das Audio bleibt auf dem eigenen Server (kein Cloud-Upload)
    und wird nach der Transkription sofort gelöscht. Ist faster-whisper nicht
    installiert, antwortet der Endpoint mit 503 – die Oberfläche fällt dann
    automatisch auf die Browser-Spracherkennung zurück.
    """
    audio = request.FILES.get('audio')
    if not audio:
        return JsonResponse({'ok': False, 'error': 'Es wurde kein Audio übertragen.'}, status=400)
    suffix = Path(audio.name or 'diktat.webm').suffix or '.webm'
    try:
        text = transcribe_audio(audio.read(), suffix=suffix)
    except TranscriptionUnavailable as e:
        return JsonResponse({'ok': False, 'error': str(e), 'code': 'stt_unavailable'}, status=503)
    except ValueError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)
    except Exception:
        logger.exception('Transkription fehlgeschlagen')
        return JsonResponse({'ok': False, 'error': 'Die Aufnahme konnte nicht transkribiert werden. Bitte erneut versuchen.'}, status=500)
    if not text:
        return JsonResponse({'ok': False, 'error': 'In der Aufnahme wurde keine Sprache erkannt. Bitte erneut diktieren.'}, status=422)
    write_audit(request, 'generate', object_type='KI', object_repr='Transkription',
                message=f'Diktat lokal transkribiert ({len(text)} Zeichen)')
    return JsonResponse({'ok': True, 'text': text})


def _read_json_body(request, max_bytes: int = MAX_AI_REQUEST_BYTES):
    """Liest den JSON-Body eines KI-Requests defensiv ein (None bei Fehlern)."""
    if len(request.body) > max_bytes:
        return None
    try:
        data = json.loads(request.body.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None
    return data if isinstance(data, dict) else None


@login_required
@require_POST
def ai_polish_text(request):
    """Magic-Tone: lose/emotionale Ansage → professionelle Leistungsbeschreibung.

    Datenschutz: Es wird ausschließlich der eingegebene Text übertragen; der
    System-Prompt weist Claude an, Namen/Adressen ersatzlos wegzulassen.
    """
    if not ai_is_configured():
        return JsonResponse({'ok': False, 'error': 'Kein Claude-API-Key hinterlegt. Bitte unter Einstellungen → KI-Assistent eintragen.'}, status=400)
    data = _read_json_body(request)
    if data is None:
        return JsonResponse({'ok': False, 'error': 'Ungültige Anfrage.'}, status=400)
    text = (data.get('text') or '').strip()
    if len(text) < 3:
        return JsonResponse({'ok': False, 'error': 'Bitte zuerst einen Text eingeben oder diktieren.'}, status=400)
    try:
        result = polish_service_text(text)
    except AIError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=502)
    except Exception:
        logger.exception('Magic-Tone-Formulierung fehlgeschlagen')
        return JsonResponse({'ok': False, 'error': 'Unerwarteter Fehler bei der KI-Formulierung. Bitte erneut versuchen.'}, status=500)
    write_audit(request, 'generate', object_type='KI', object_repr='Magic-Tone',
                message=f'Leistungstext veredelt ({len(text)} → {len(result)} Zeichen)')
    return JsonResponse({'ok': True, 'text': result})


def _invoice_ai_context(invoice: Invoice) -> list[str]:
    """Eckdaten einer Rechnung für KI-Aufrufe – AUSSCHLIESSLICH Leistungsdaten.

    Bewusst ohne Kunden- und Objektdaten (Datenschutzregel des Projekts).
    """
    lines = [
        f'Rechnungsnummer: {invoice.number}',
        f'Bruttobetrag: {invoice.gross_total} EUR',
        f'Fällig bis: {invoice.due_date.strftime("%d.%m.%Y") if invoice.due_date else "siehe Rechnung"}',
    ]
    if invoice.period_start and invoice.period_end:
        lines.append(f'Leistungszeitraum: {invoice.period_start.strftime("%d.%m.%Y")} – {invoice.period_end.strftime("%d.%m.%Y")}')
    items = list(invoice.items.all()[:10])
    if items:
        lines.append('Positionen:')
        lines.extend(f'- {item.description}' for item in items)
    return lines


@login_required
@require_POST
def ai_cover_letter(request):
    """Magic-Tone: KI-Begleittext für den Rechnungsversand erzeugen.

    Der Kontext wird serverseitig aus der Rechnung gebaut und enthält nur
    Leistungsdaten (Nummer, Betrag, Fälligkeit, Positionsbezeichnungen).
    """
    if not ai_is_configured():
        return JsonResponse({'ok': False, 'error': 'Kein Claude-API-Key hinterlegt. Bitte unter Einstellungen → KI-Assistent eintragen.'}, status=400)
    data = _read_json_body(request)
    if data is None:
        return JsonResponse({'ok': False, 'error': 'Ungültige Anfrage.'}, status=400)
    invoice = Invoice.objects.filter(pk=data.get('invoice')).first()
    if not invoice:
        return JsonResponse({'ok': False, 'error': 'Rechnung wurde nicht gefunden.'}, status=404)
    hint = (data.get('hint') or '').strip()
    try:
        body = generate_cover_letter_text(_invoice_ai_context(invoice), hint)
    except AIError as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=502)
    except Exception:
        logger.exception('KI-Begleittext fehlgeschlagen')
        return JsonResponse({'ok': False, 'error': 'Unerwarteter Fehler beim Begleittext. Bitte erneut versuchen.'}, status=500)
    write_audit(request, 'generate', invoice, f'KI-Begleittext zu {invoice.number} erzeugt')
    return JsonResponse({'ok': True, 'text': body})


@login_required
@require_POST
def ai_plausibility(request):
    """Plausibilitäts-Check der aktuellen Positionen (Prüfen-Schritt).

    Zweistufig: Der LOKALE Teil (Preis-Ausreißer gegen die eigene Kunden-
    historie, Dubletten, Nullwerte) läuft komplett auf diesem Server – die
    Kundennummer wird dafür NICHT an Claude übertragen. Der optionale KI-Teil
    prüft ausschließlich die Leistungsdaten (Bezeichnung/Menge/Einheit/Preis).
    """
    data = _read_json_body(request)
    if data is None:
        return JsonResponse({'ok': False, 'error': 'Ungültige Anfrage.'}, status=400)
    raw_positions = data.get('positionen')
    if not isinstance(raw_positions, list) or not raw_positions:
        return JsonResponse({'ok': False, 'error': 'Keine Positionen übergeben.'}, status=400)
    positions = [p for p in raw_positions[:40] if isinstance(p, dict)]
    mode = data.get('mode') if data.get('mode') in ('lokal', 'ki', 'beides') else 'lokal'
    customer_id = data.get('customer') or None

    lokal = check_positions_local(customer_id, positions)

    ki = None
    ki_error = ''
    if mode in ('ki', 'beides'):
        if not ai_is_configured():
            ki_error = 'Kein Claude-API-Key hinterlegt. Bitte unter Einstellungen → KI-Assistent eintragen.'
        else:
            try:
                ki = ai_review_positions(positions)
                write_audit(request, 'generate', object_type='KI', object_repr='Plausibilitäts-Check',
                            message=f'KI-Check: {len(ki)} Befund(e) bei {len(positions)} Position(en)')
            except AIError as e:
                ki_error = str(e)
            except Exception:
                logger.exception('KI-Plausibilitätscheck fehlgeschlagen')
                ki_error = 'Unerwarteter Fehler beim KI-Check. Bitte erneut versuchen.'
    return JsonResponse({'ok': True, 'lokal': lokal, 'ki': ki, 'ki_error': ki_error})


@login_required
def service_catalog_list(request):
    """Leistungskatalog: Übersicht aller (auch KI-gelernten) Leistungen."""
    q = (request.GET.get('q') or '').strip()
    items = ServiceCatalogItem.objects.all()
    if q:
        items = items.filter(Q(name__icontains=q) | Q(long_text__icontains=q))
    return render(request, 'sedo/service_catalog_list.html', {'items': items, 'q': q})


@login_required
def service_catalog_create(request):
    form = ServiceCatalogItemForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        item = form.save()
        write_audit(request, 'create', item, f'Katalog-Leistung „{item.name}" angelegt')
        messages.success(request, f'Leistung „{item.name}" wurde angelegt.')
        return redirect('sedo:service_catalog_list')
    return render(request, 'sedo/service_catalog_form.html', {'form': form, 'title': 'Neue Katalog-Leistung'})


@login_required
def service_catalog_update(request, pk):
    item = get_object_or_404(ServiceCatalogItem, pk=pk)
    form = ServiceCatalogItemForm(request.POST or None, instance=item)
    if request.method == 'POST' and form.is_valid():
        item = form.save(commit=False)
        item.created_by_ai = False  # manuell geprüft/überarbeitet
        item.save()
        write_audit(request, 'update', item, f'Katalog-Leistung „{item.name}" bearbeitet')
        messages.success(request, f'Leistung „{item.name}" wurde gespeichert.')
        return redirect('sedo:service_catalog_list')
    return render(request, 'sedo/service_catalog_form.html', {'form': form, 'title': f'Leistung bearbeiten: {item.name}', 'item': item})


@login_required
def service_catalog_delete(request, pk):
    item = get_object_or_404(ServiceCatalogItem, pk=pk)
    if request.method == 'POST':
        name = item.name
        item.delete()
        write_audit(request, 'delete', object_type='ServiceCatalogItem', object_repr=name,
                    message=f'Katalog-Leistung „{name}" gelöscht')
        messages.success(request, f'Leistung „{name}" wurde gelöscht.')
        return redirect('sedo:service_catalog_list')
    return render(request, 'sedo/confirm_delete.html', {
        'title': 'Katalog-Leistung löschen',
        'text': f'Soll die Leistung „{item.name}" wirklich aus dem Katalog gelöscht werden? Bestehende Angebote bleiben unverändert.',
        'cancel_url': reverse('sedo:service_catalog_list'),
    })

@login_required
def dashboard(request):
    today = timezone.localdate()
    invoices = Invoice.objects.all()
    dunning_candidates = get_dunning_candidates(days_overdue_threshold=14)
    context = {
        'open_invoices': invoices.exclude(status__in=['bezahlt','storniert']).count(),
        'open_amount_total': sum((i.open_amount for i in invoices.exclude(status__in=['bezahlt','storniert']).prefetch_related('payments')), Decimal('0.00')),
        'overdue_invoices': invoices.exclude(status__in=['bezahlt','storniert']).filter(due_date__lt=today).count(),
        'paid_month': _sum_decimal(invoices.filter(status='bezahlt', issue_date__year=today.year, issue_date__month=today.month), 'gross_total'),
        'open_offers': Offer.objects.filter(status='offen').count(),
        'customers': Customer.objects.count(),
        'latest_invoices': Invoice.objects.select_related('customer','obj')[:8],
        'latest_offers': Offer.objects.select_related('customer','obj')[:5],
        'dunning_candidates_count': len(dunning_candidates),
        'smtp_configured': smtp_is_configured(),
        'ai_configured': ai_is_configured(),
        'ai_text_model': AppSetting.get('ai_text_model', ''),
        'ai_default_text_model': AI_DEFAULT_TEXT_MODEL,
    }
    return render(request, 'sedo/dashboard.html', context)


@login_required
def customer_list(request):
    q = request.GET.get('q','').strip()
    customers = Customer.objects.all()
    if q:
        customers = customers.filter(Q(name__icontains=q) | Q(customer_no__icontains=q) | Q(email__icontains=q) | Q(city__icontains=q))
    return render(request, 'sedo/customer_list.html', {'customers': customers, 'q': q})


@login_required
def customer_import(request):
    stats = None
    if request.method == 'POST' and request.FILES.get('file'):
        file = request.FILES['file']
        name = file.name.lower()
        if name.endswith('.csv'):
            decoded = file.read().decode('utf-8-sig').splitlines()
            delimiter = ';' if (decoded and ';' in decoded[0]) else ','
            rows = list(csv.DictReader(decoded, delimiter=delimiter))
        else:
            df = pd.read_excel(file)
            rows = df.to_dict('records')
        created = updated = 0
        for row in rows:
            customer_no = _pick(row, 'Kunden-Nr.', 'Kundennummer', 'Kunden Nr', 'Kdnr', 'KdNr')
            name_value = _pick_customer_name(row)
            if not name_value:
                continue
            defaults = {
                'salutation': _pick(row, 'Anrede'),
                'customer_type': _pick(row, 'Kundentyp') or 'einmalig',
                'name': name_value,
                'name2': _pick(row, 'Name Zusatz', 'Zusatz', 'Adresszusatz'),
                'contact_person': _pick(row, 'Ansprechpartner', 'Kontaktperson'),
                'phone': _pick(row, 'Telefon', 'Tel', 'Telefonnummer', 'Mobil'),
                'email': _pick(row, 'E-Mail', 'Email', 'Mail'),
                'street': (_pick(row, 'Straße', 'Strasse', 'Adresse') + (' ' + _pick(row, 'Hausnummer', 'Hausnr.') if _pick(row, 'Hausnummer', 'Hausnr.') else '')).strip(),
                'postcode': _pick(row, 'PLZ', 'Postleitzahl'),
                'city': _pick(row, 'Stadt', 'Ort'),
                'country': _pick(row, 'Land') or 'DE',
            }
            if customer_no:
                obj, was_created = Customer.objects.update_or_create(customer_no=customer_no, defaults=defaults)
            else:
                obj, was_created = Customer.objects.update_or_create(name=name_value, defaults=defaults)
            created += 1 if was_created else 0
            updated += 0 if was_created else 1
        stats = {'created': created, 'updated': updated, 'total': created + updated}
        messages.success(request, f"Kundenimport abgeschlossen: {created} neu, {updated} aktualisiert.")
    return render(request, 'sedo/customer_import.html', {'stats': stats})


@login_required
def customer_create(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            c = form.save()
            messages.success(request, 'Kunde gespeichert.')
            return redirect('sedo:customer_detail', c.pk)
    else:
        form = CustomerForm()
    return render(request, 'sedo/customer_form.html', {'form': form, 'title': 'Neuen Kunden anlegen'})


@login_required
def customer_update(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Kunde aktualisiert.')
            return redirect('sedo:customer_detail', customer.pk)
    else:
        form = CustomerForm(instance=customer)
    return render(request, 'sedo/customer_form.html', {'form': form, 'title': 'Kunden bearbeiten'})


@login_required
def customer_detail(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    # Rückwärtsrelationen laufen über all_objects; soft-gelöschte Datensätze ausblenden.
    invoices = customer.invoices.filter(deleted_at__isnull=True).select_related('obj').order_by('-issue_date')
    offers = customer.offers.filter(deleted_at__isnull=True).select_related('obj').order_by('-issue_date')
    return render(request, 'sedo/customer_detail.html', {
        'customer': customer,
        'customer_invoices': invoices,
        'customer_offers': offers,
    })


@login_required
def object_create(request):
    if request.method == 'POST':
        form = CustomerObjectForm(request.POST)
        if form.is_valid():
            obj = form.save()
            messages.success(request, 'Objekt gespeichert.')
            return redirect('sedo:customer_detail', obj.customer_id)
    else:
        form = CustomerObjectForm(initial={'customer': request.GET.get('customer')})
    return render(request, 'sedo/object_form.html', {'form': form, 'title':'Objekt anlegen'})


@login_required
def object_update(request, pk):
    obj = get_object_or_404(CustomerObject, pk=pk)
    if request.method == 'POST':
        form = CustomerObjectForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Objekt aktualisiert.')
            return redirect('sedo:customer_detail', obj.customer_id)
    else:
        form = CustomerObjectForm(instance=obj)
    return render(request, 'sedo/object_form.html', {'form': form, 'title':'Objekt bearbeiten'})


@login_required
def object_delete(request, pk):
    obj = get_object_or_404(CustomerObject, pk=pk)
    customer_id = obj.customer_id
    if request.method == 'POST':
        obj.delete()
        messages.success(request, 'Objekt gelöscht.')
        return redirect('sedo:customer_detail', customer_id)
    return render(request, 'sedo/confirm_delete.html', {'title':'Objekt löschen', 'text':f'Objekt „{obj}“ wirklich löschen?', 'cancel_url': reverse('sedo:customer_detail', args=[customer_id])})


@login_required
def invoice_list(request):
    q        = request.GET.get('q', '').strip()
    year_s   = request.GET.get('year', '').strip()
    month_s  = request.GET.get('month', '').strip()
    status_f = request.GET.get('status', '').strip()

    invoices = Invoice.objects.select_related('customer', 'obj').all()

    if q:
        invoices = invoices.filter(
            Q(number__icontains=q) | Q(customer__name__icontains=q) | Q(obj__name__icontains=q)
        )
    if year_s.isdigit():
        invoices = invoices.filter(issue_date__year=int(year_s))
    if month_s.isdigit():
        invoices = invoices.filter(issue_date__month=int(month_s))
    if status_f:
        invoices = invoices.filter(status=status_f)

    # Verfügbare Jahre für das Filter-Dropdown
    available_years = (
        Invoice.objects.annotate(y=ExtractYear('issue_date'))
        .values_list('y', flat=True).distinct().order_by('-y')
    )
    gross_total = _sum_decimal(invoices, 'gross_total')

    return render(request, 'sedo/invoice_list.html', {
        'invoices': invoices,
        'q': q,
        'year': year_s,
        'month': month_s,
        'status': status_f,
        'available_years': available_years,
        'gross_total': gross_total,
        'status_choices': Invoice.STATUS,
    })


@login_required
def invoice_create(request):
    pre_customer = request.GET.get('customer')
    pre_offer = request.GET.get('from_offer')
    pre_correction = request.GET.get('correction_of')
    initial = {'payment_days': 14, 'issue_date': timezone.localdate(), 'vat_rate': Decimal('19.00')}
    invoice = Invoice(number=next_number('RE'), issue_date=timezone.localdate(), vat_rate=Decimal('19.00'))
    offer = None
    correction_source = None
    item_initial = None

    if pre_offer:
        offer = get_object_or_404(Offer.objects.select_related('customer','obj'), pk=pre_offer)
        try:
            ensure_offer_invoicing_allowed(offer)
        except WorkflowError as e:
            messages.error(request, str(e))
            return redirect('sedo:offer_detail', offer.pk)
        initial.update({'customer': offer.customer_id, 'vat_rate': offer.vat_rate, 'note': f'Diese Rechnung beruht auf Angebot {offer.number}.'})
        if offer.obj_id:
            initial['obj'] = offer.obj_id
        item_initial = [{
            'description': item.description,
            'long_text': item.long_text,
            'quantity': item.quantity,
            'unit': item.unit,
            'unit_price': item.unit_price,
            'article_no': item.article_no,
        } for item in offer.items.all()]
    elif pre_correction:
        correction_source = get_object_or_404(Invoice.objects.select_related('customer','obj'), pk=pre_correction)
        try:
            ensure_correction_allowed(correction_source)
        except WorkflowError as e:
            messages.error(request, str(e))
            return redirect('sedo:invoice_detail', correction_source.pk)
        initial.update({
            'customer': correction_source.customer_id,
            'obj': correction_source.obj_id,
            'vat_rate': correction_source.vat_rate,
            'period_start': correction_source.period_start,
            'period_end': correction_source.period_end,
            'note': f'Korrekturrechnung zu {correction_source.number}.',
        })
        item_initial = _invoice_items_initial_from_invoice(correction_source)
    elif pre_customer:
        customer = get_object_or_404(Customer, pk=pre_customer)
        initial['customer'] = customer.pk
        initial['payment_days'] = customer.payment_days

    # Für Angebote/Korrekturen genug leere/gefüllte Positionsformulare bereitstellen
    extra_count = max(1, len(item_initial or []))
    DynamicInvoiceItemFormSet = InvoiceItemFormSet
    if item_initial:
        from django.forms import inlineformset_factory
        from .forms import InvoiceItemForm
        DynamicInvoiceItemFormSet = inlineformset_factory(Invoice, InvoiceItem, form=InvoiceItemForm, extra=extra_count, can_delete=True, min_num=1, validate_min=True)

    if request.method == 'POST':
        form = InvoiceForm(request.POST, instance=invoice)
        formset = InvoiceItemFormSet(request.POST, instance=invoice)
        action = request.POST.get('action')
        if form.is_valid() and formset.is_valid():
            if action == 'preview':
                preview = _preview_from_forms(form, formset, title='Entwurfsansicht Rechnung')
                return render(request, 'sedo/invoice_preview.html', {'preview': preview, 'back_post': request.POST})
            customer = _customer_from_invoice_form(form)
            if not customer:
                form.add_error('name', 'Bitte einen gespeicherten Kunden auswählen oder die Kopfdaten mit Name/Firma ausfüllen.')
            else:
                obj = _object_from_invoice_form(form, customer)
                inv = form.save(commit=False)
                inv.customer = customer
                inv.obj = obj
                inv.due_date = inv.issue_date + timedelta(days=form.cleaned_data.get('payment_days') or customer.payment_days)
                inv.invoice_type = '380'
                inv.status = 'entwurf' if action == 'draft' else 'erstellt'
                src_offer = None
                src_invoice = None
                if request.POST.get('source_offer'):
                    src_offer = get_object_or_404(Offer, pk=request.POST.get('source_offer'))
                    # Serverseitige Sperre gegen doppelte Rechnungsstellung aus
                    # demselben Angebot (die UI versteckt nur den Button).
                    try:
                        ensure_offer_invoicing_allowed(src_offer)
                    except WorkflowError as e:
                        messages.error(request, str(e))
                        return redirect('sedo:offer_detail', src_offer.pk)
                    inv.source = 'Angebot'
                    inv.note = inv.note or f'Diese Rechnung beruht auf Angebot {src_offer.number}.'
                if request.POST.get('correction_of'):
                    src_invoice = get_object_or_404(Invoice, pk=request.POST.get('correction_of'))
                    try:
                        ensure_correction_allowed(src_invoice)
                    except WorkflowError as e:
                        messages.error(request, str(e))
                        return redirect('sedo:invoice_detail', src_invoice.pk)
                    inv.invoice_type = '384'
                    inv.source = 'Korrektur'
                    inv.reference_invoice = src_invoice
                    inv.note = inv.note or f'Korrekturrechnung zu {src_invoice.number}.'
                # Atomar: Rechnung, Positionen, Dateien und Verknüpfungen
                # entstehen ganz oder gar nicht (keine halben Rechnungen).
                # WorkflowError/Unique-Constraint decken dabei auch den Fall
                # ab, dass zwei parallele Requests die ensure-Guards passieren.
                try:
                    with transaction.atomic():
                        # Kollisionssichere Rechnungsnummer vergeben und speichern
                        save_with_unique_number(inv, 'RE')
                        formset.instance = inv
                        formset.save()
                        _normalize_item_positions(inv.items.all())
                        recalc_invoice(inv)
                        inv.save()
                        if action != 'draft':
                            generate_invoice_files(inv)
                        if src_offer:
                            # Guarded UPDATE: nur wenn das Angebot noch nicht
                            # verrechnet ist – sonst rollt alles zurück.
                            updated = Offer.objects.filter(
                                pk=src_offer.pk, linked_invoice__isnull=True,
                            ).exclude(status='in_rechnung').update(
                                status='in_rechnung', linked_invoice=inv,
                                updated_at=timezone.now(),
                            )
                            if not updated:
                                raise WorkflowError(
                                    f'Aus Angebot {src_offer.number} wurde soeben bereits '
                                    f'eine Rechnung erzeugt (paralleler Vorgang).')
                        if src_invoice and action != 'draft':
                            # Ursprungsrechnung als korrigiert markieren – blockiert
                            # damit weitere Korrekturen und Stornos des Originals.
                            # (Bei Entwürfen greift bereits die Folgebeleg-Sperre.)
                            mark_invoice_corrected(src_invoice)
                except WorkflowError as e:
                    messages.error(request, str(e))
                    target = ('sedo:offer_detail', src_offer.pk) if src_offer \
                        else ('sedo:invoice_detail', src_invoice.pk) if src_invoice \
                        else ('sedo:invoice_list', None)
                    return redirect(target[0], target[1]) if target[1] else redirect(target[0])
                except IntegrityError as e:
                    # SQLite meldet die Spalte (reference_invoice_id) statt des
                    # Constraint-Namens; im Korrektur-Kontext ist das eindeutig.
                    if src_invoice and ('reference_invoice_id' in str(e)
                                        or 'invoice_unique_active_correction' in str(e)):
                        messages.error(request, f'Zu Rechnung {src_invoice.number} wurde soeben '
                                                f'bereits eine Korrekturrechnung erzeugt (paralleler Vorgang).')
                        return redirect('sedo:invoice_detail', src_invoice.pk)
                    raise
                if request.POST.get('save_as_recurring'):
                    tmpl_title = request.POST.get('recurring_title') or ''
                    tmpl = _create_recurring_template_from_invoice(inv, tmpl_title.strip() or None)
                    messages.success(request, f'Abo-/Monatsrechnungsvorlage „{tmpl.title}“ wurde gespeichert.')
                if action == 'send':
                    if not inv.customer.email:
                        messages.warning(request, f'Rechnung {inv.number} wurde erzeugt, aber es ist keine E-Mail-Adresse beim Kunden hinterlegt.')
                        return redirect('sedo:invoice_detail', inv.pk)
                    inv.status = 'versendet'; inv.save(update_fields=['status','updated_at'])
                    eml_path = _create_invoice_email_file(inv)
                    write_audit(request, 'create', inv, f'Rechnung {inv.number} erzeugt und E-Mail-Entwurf erstellt')
                    messages.success(request, f'Rechnung {inv.number} wurde erzeugt und ein E-Mail-Entwurf wurde erstellt.')
                    if eml_path and Path(eml_path).exists():
                        return FileResponse(open(eml_path, 'rb'), as_attachment=True, filename=Path(eml_path).name)
                    return redirect('sedo:invoice_detail', inv.pk)
                if action == 'draft':
                    write_audit(request, 'create', inv, f'Rechnungsentwurf {inv.number} gespeichert')
                    messages.success(request, f'Entwurf {inv.number} gespeichert.')
                else:
                    write_audit(request, 'create', inv, f'Rechnung {inv.number} erzeugt')
                    messages.success(request, f'Rechnung {inv.number} erzeugt.')
                return redirect('sedo:invoice_detail', inv.pk)
    else:
        form = InvoiceForm(instance=invoice, initial=initial)
        if pre_customer:
            _fill_customer_initial(form, Customer.objects.get(pk=pre_customer))
        if offer:
            _fill_customer_initial(form, offer.customer)
            _fill_object_initial(form, offer.obj)
        if correction_source:
            _fill_customer_initial(form, correction_source.customer)
            _fill_object_initial(form, correction_source.obj)
        formset = DynamicInvoiceItemFormSet(instance=invoice, queryset=InvoiceItem.objects.none(), initial=item_initial or None)
    return render(request, 'sedo/invoice_form.html', {
        'form': form,
        'formset': formset,
        'title': 'Korrekturrechnung erstellen' if correction_source else 'Neue Rechnung',
        'source_offer': offer,
        'correction_source': correction_source,
        'smtp_configured': smtp_is_configured(),
    })


@login_required
def invoice_detail(request, pk):
    invoice = get_object_or_404(Invoice.objects.select_related('customer','obj'), pk=pk)
    # Rückwärtsrelation läuft über all_objects; soft-gelöschte Zahlungen ausblenden.
    payments = invoice.payments.filter(deleted_at__isnull=True).order_by('-booking_date')
    return render(request, 'sedo/invoice_detail.html', {'invoice': invoice, 'invoice_payments': payments})


@login_required
@require_POST
def invoice_generate(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    generate_invoice_files(invoice)
    write_audit(request, 'generate', invoice, 'Rechnungsdateien neu erzeugt')
    messages.success(request, 'Rechnungsdateien wurden neu erzeugt.')
    return redirect('sedo:invoice_detail', pk)


@login_required
@require_POST
def invoice_email(request, pk):
    invoice = get_object_or_404(Invoice.objects.select_related('customer'), pk=pk)
    if not invoice.customer.email:
        messages.error(request, 'Beim Kunden ist keine E-Mail-Adresse hinterlegt.')
        return redirect('sedo:invoice_detail', pk)

    generate_invoice_files(invoice)
    recipient = invoice.customer.email
    subject, body = invoice_email_subject_body(invoice)
    # Optionaler individueller Begleittext (z. B. per Magic-Tone erzeugt und geprüft)
    custom_body = (request.POST.get('body') or '').strip()
    if custom_body:
        body = custom_body
    attachment = Path(invoice.zugferd_file.path) if invoice.zugferd_file else None

    # Wenn SMTP konfiguriert: direkt senden, sonst .eml zum Download
    if smtp_is_configured():
        try:
            send_email_smtp(recipient, subject, body, attachment)
            if invoice.status != 'storniert':
                invoice.status = 'versendet'
                invoice.save(update_fields=['status', 'updated_at'])
            write_audit(request, 'generate', invoice, f'Rechnung {invoice.number} direkt per SMTP versendet an {recipient}')
            messages.success(request, f'Rechnung {invoice.number} wurde direkt an {recipient} versendet.')
            return redirect('sedo:invoice_detail', pk)
        except Exception as e:
            logger.exception('SMTP-Rechnungsversand fehlgeschlagen')
            messages.error(request, f'E-Mail-Versand fehlgeschlagen: {e}')
            return redirect('sedo:invoice_detail', pk)
    else:
        # Fallback: .eml-Datei zum Download
        out_dir = Path(settings.MEDIA_ROOT) / 'emails' / invoice.number
        eml_path = create_email_draft(recipient, subject, body, attachment, out_dir, f'{invoice.number}_email')
        if invoice.status != 'storniert':
            invoice.status = 'versendet'
            invoice.save(update_fields=['status', 'updated_at'])
        write_audit(request, 'generate', invoice, 'E-Mail-Entwurf (.eml) zur Rechnung erzeugt')
        if not eml_path or not Path(eml_path).exists():
            messages.error(request, 'E-Mail-Entwurf konnte nicht erzeugt werden.')
            return redirect('sedo:invoice_detail', pk)
        return FileResponse(open(eml_path, 'rb'), as_attachment=True, filename=Path(eml_path).name)

@login_required
def invoice_correction(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    # Serverseitige Sperre: stornierte/bereits korrigierte Rechnungen und
    # Stornos dürfen nicht als Korrekturgrundlage geladen werden.
    try:
        ensure_correction_allowed(invoice)
    except WorkflowError as e:
        messages.error(request, str(e))
        return redirect('sedo:invoice_detail', invoice.pk)
    return redirect(f"{reverse('sedo:invoice_create')}?correction_of={invoice.pk}")


@login_required
@require_POST
def invoice_storno(request, pk):
    original = get_object_or_404(Invoice, pk=pk)
    try:
        storno = create_storno(original)
    except WorkflowError as e:
        messages.error(request, str(e))
        return redirect('sedo:invoice_detail', original.pk)
    write_audit(request, 'generate', storno, f'Stornorechnung zu {original.number} erzeugt')
    messages.success(request, f'Stornorechnung {storno.number} erzeugt.')
    return redirect('sedo:invoice_detail', storno.pk)


@login_required
def invoice_delete(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    if request.method == 'POST':
        no = invoice.number
        write_audit(request, 'delete', invoice, f'Rechnung {no} als gelöscht markiert (GoBD-Soft-Delete)')
        # GoBD: Rechnungen werden nicht hart entfernt, sondern nur ausgeblendet.
        invoice.soft_delete()
        messages.success(request, f'Rechnung {no} wurde ausgeblendet. Der Datensatz bleibt für die Nachvollziehbarkeit erhalten (GoBD).')
        return redirect('sedo:invoice_list')
    return render(request, 'sedo/confirm_delete.html', {'title': 'Rechnung ausblenden', 'text': f'Rechnung {invoice.number} wirklich ausblenden? Der Datensatz bleibt GoBD-konform erhalten und wird nur nicht mehr angezeigt.', 'cancel_url': reverse('sedo:invoice_detail', args=[pk])})


@login_required
def offer_list(request):
    q = request.GET.get('q','').strip()
    offers = Offer.objects.select_related('customer','obj','linked_invoice').all()
    if q:
        offers = offers.filter(Q(number__icontains=q) | Q(customer__name__icontains=q) | Q(obj__name__icontains=q))
    return render(request, 'sedo/offer_list.html', {'offers': offers, 'q': q})


@login_required
def offer_create(request):
    offer = Offer(number=next_number('AG'), issue_date=timezone.localdate(), vat_rate=Decimal('19.00'))
    if request.method == 'POST':
        form = OfferForm(request.POST, instance=offer)
        formset = OfferItemFormSet(request.POST, instance=offer)
        action = request.POST.get('action')
        if form.is_valid() and formset.is_valid():
            if action == 'preview':
                preview = _preview_from_forms(form, formset, title='Entwurfsansicht Angebot')
                return render(request, 'sedo/invoice_preview.html', {'preview': preview, 'is_offer': True})
            customer = _customer_from_invoice_form(form)
            if not customer:
                form.add_error('name', 'Bitte einen gespeicherten Kunden auswählen oder die Kopfdaten mit Name/Firma ausfüllen.')
            else:
                obj = _object_from_invoice_form(form, customer)
                off = form.save(commit=False)
                off.customer = customer
                off.obj = obj
                off.valid_until = off.issue_date + timedelta(days=form.cleaned_data.get('valid_days') or DEFAULT_PAYMENT_DAYS)
                off.status = 'offen'
                # Kollisionssichere Angebotsnummer vergeben und speichern
                save_with_unique_number(off, 'AG')
                formset.instance = off
                formset.save()
                # Positionsnummern normalisieren (sonst steht im PDF überall „1“)
                _normalize_item_positions(off.items.all())
                recalc_offer(off)
                off.save()
                generate_offer_pdf(off)
                write_audit(request, 'create', off, f'Angebot {off.number} erstellt')
                messages.success(request, f'Angebot {off.number} gespeichert.')
                return redirect('sedo:offer_detail', off.pk)
    else:
        form = OfferForm(instance=offer, initial={'valid_days':14, 'issue_date': timezone.localdate(), 'vat_rate': Decimal('19.00')})
        formset = OfferItemFormSet(instance=offer)
    return render(request, 'sedo/offer_form.html', {
        'form': form,
        'formset': formset,
        # Lokales Whisper verfügbar? Steuert, ob das Diktat über den Server
        # transkribiert wird oder die Browser-Spracherkennung nutzt.
        'stt_available': stt_status()['available'],
    })


@login_required
def offer_detail(request, pk):
    offer = get_object_or_404(Offer.objects.select_related('customer','obj','linked_invoice'), pk=pk)
    return render(request, 'sedo/offer_detail.html', {'offer': offer})


@login_required
@require_POST
def offer_generate(request, pk):
    offer = get_object_or_404(Offer, pk=pk)
    generate_offer_pdf(offer)
    write_audit(request, 'generate', offer, 'Angebots-PDF neu erzeugt')
    messages.success(request, 'Angebots-PDF wurde neu erzeugt.')
    return redirect('sedo:offer_detail', pk)


@login_required
@require_POST
def offer_status(request, pk, status):
    offer = get_object_or_404(Offer, pk=pk)
    if status in ['offen', 'angenommen', 'abgelehnt']:
        offer.status = status
        offer.save(update_fields=['status', 'updated_at'])
        write_audit(request, 'update', offer, f'Angebotsstatus auf {status} gesetzt')
        messages.success(request, 'Angebotsstatus aktualisiert.')
    return redirect('sedo:offer_detail', pk)


@login_required
@require_POST
def offer_to_invoice(request, pk):
    offer = get_object_or_404(Offer, pk=pk)
    try:
        inv = create_invoice_from_offer(offer)
    except WorkflowError as e:
        messages.error(request, str(e))
        return redirect('sedo:offer_detail', offer.pk)
    write_audit(request, 'generate', inv, f'Rechnung aus Angebot {offer.number} erzeugt')
    messages.success(request, f'Rechnung {inv.number} aus Angebot {offer.number} erzeugt.')
    return redirect('sedo:invoice_detail', inv.pk)


@login_required
def offer_delete(request, pk):
    offer = get_object_or_404(Offer, pk=pk)
    if request.method == 'POST':
        no = offer.number
        write_audit(request, 'delete', offer, f'Angebot {no} als gelöscht markiert (GoBD-Soft-Delete)')
        # GoBD: Angebote sind Geschäftsbriefe – nur ausblenden, nicht hart löschen.
        offer.soft_delete(); messages.success(request, f'Angebot {no} wurde ausgeblendet. Der Datensatz bleibt für die Nachvollziehbarkeit erhalten (GoBD).'); return redirect('sedo:offer_list')
    return render(request, 'sedo/confirm_delete.html', {'title':'Angebot ausblenden', 'text':f'Angebot {offer.number} wirklich ausblenden? Der Datensatz bleibt GoBD-konform erhalten und wird nur nicht mehr angezeigt.', 'cancel_url': reverse('sedo:offer_detail', args=[pk])})


@login_required
def open_items(request):
    today = timezone.localdate()
    status = request.GET.get('status', 'open')
    q = request.GET.get('q', '').strip()
    invoices = Invoice.objects.select_related('customer','obj').prefetch_related('payments','dunning_documents').exclude(status='storniert')
    if status == 'overdue':
        invoices = invoices.exclude(status='bezahlt').filter(due_date__lt=today)
    elif status == 'paid':
        invoices = invoices.filter(status='bezahlt')
    elif status == 'all':
        pass
    else:
        invoices = invoices.exclude(status='bezahlt')
    if q:
        invoices = invoices.filter(Q(number__icontains=q) | Q(customer__name__icontains=q) | Q(obj__name__icontains=q))
    invoice_list = list(invoices[:MAX_OPEN_ITEMS])
    for inv in invoice_list:
        refresh_invoice_payment_status(inv)
    open_total = sum((i.open_amount for i in invoice_list if i.status != 'bezahlt'), Decimal('0.00'))
    overdue_total = sum((i.open_amount for i in invoice_list if i.is_overdue), Decimal('0.00'))
    dunning_candidates = get_dunning_candidates()
    return render(request, 'sedo/open_items.html', {
        'invoices': invoice_list,
        'status': status,
        'q': q,
        'today': today,
        'open_total': open_total,
        'overdue_total': overdue_total,
        'overdue_count': len([i for i in invoice_list if i.is_overdue]),
        'dunning_candidates': dunning_candidates,
        'dunning_candidates_count': len(dunning_candidates),
    })


@login_required
def bulk_dunning(request):
    """Batch-Mahnung: Mehrere Rechnungen gleichzeitig mahnen."""
    if request.method != 'POST':
        return redirect('sedo:open_items')
    kind = request.POST.get('kind', 'auto')
    if kind not in ('reminder', 'dunning', 'auto'):
        kind = 'auto'
    # Entweder explizit ausgewählte IDs oder alle Mahnkandidaten
    selected = request.POST.getlist('invoice_ids')
    if selected:
        result = send_bulk_dunning(selected, kind)
    else:
        candidates = get_dunning_candidates()
        result = send_bulk_dunning([str(inv.pk) for inv in candidates], kind)
    label = {'reminder': 'Zahlungserinnerungen', 'dunning': 'Mahnungen'}.get(kind, 'Mahnschreiben (Stufe automatisch)')
    write_audit(request, 'generate', object_type='Mahnung', object_repr='Batch',
                message=f'{result["created"]} {label} erstellt, {result["skipped"]} übersprungen')
    messages.success(request, f'{result["created"]} {label} erstellt. {result["skipped"]} übersprungen.')
    return redirect('sedo:open_items')


@login_required
def invoice_add_payment(request, pk):
    invoice = get_object_or_404(Invoice.objects.select_related('customer'), pk=pk)
    if request.method == 'POST':
        form = ManualPaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.invoice = invoice
            payment.matched_automatically = False
            if not payment.payer_name:
                payment.payer_name = invoice.customer.name
            payment.save()
            write_audit(request, 'payment', payment, f'Zahlung zu {invoice.number} erfasst')
            refresh_invoice_payment_status(invoice)
            messages.success(request, f'Zahlung über {payment.amount} € wurde zu {invoice.number} erfasst.')
            next_url = request.POST.get('next') or reverse('sedo:invoice_detail', args=[invoice.pk])
            return redirect(next_url)
    else:
        form = ManualPaymentForm(initial={
            'booking_date': timezone.localdate(),
            'amount': invoice.open_amount if invoice.open_amount > Decimal('0.00') else invoice.gross_total,
            'payer_name': invoice.customer.name,
            'purpose': f'Zahlung zu Rechnung {invoice.number}',
        })
    return render(request, 'sedo/payment_manual.html', {'form': form, 'invoice': invoice})


@login_required
def invoice_mark_paid(request, pk):
    invoice = get_object_or_404(Invoice.objects.select_related('customer'), pk=pk)
    if request.method != 'POST':
        return redirect('sedo:invoice_detail', invoice.pk)
    amount = invoice.open_amount
    if amount <= Decimal('0.00'):
        messages.info(request, 'Diese Rechnung ist bereits vollständig ausgeglichen.')
    else:
        payment = Payment.objects.create(
            invoice=invoice,
            booking_date=timezone.localdate(),
            amount=amount,
            payer_name=invoice.customer.name,
            purpose=f'Manuell als bezahlt markiert · Rechnung {invoice.number}',
            matched_automatically=False,
        )
        write_audit(request, 'payment', payment, f'Rechnung {invoice.number} manuell als bezahlt markiert')
        refresh_invoice_payment_status(invoice)
        messages.success(request, f'Rechnung {invoice.number} wurde als bezahlt markiert.')
    next_url = request.POST.get('next') or reverse('sedo:invoice_detail', args=[invoice.pk])
    return redirect(next_url)


@login_required
def payment_list(request):
    import_result = None
    if request.method == 'POST' and request.POST.get('action') == 'fints_fetch':
        # Echte Kontoanbindung (v2.3): Umsätze direkt bei der Bank abrufen.
        try:
            days = int(request.POST.get('days') or 30)
        except (TypeError, ValueError):
            days = 30
        try:
            import_result = fetch_bank_transactions(days=days,
                                                    pin=request.POST.get('fints_pin_once', ''))
            write_audit(request, 'import', object_type='Bankimport', object_repr='FinTS-Abruf',
                        message=f"FinTS: {import_result['abgerufen']} Umsätze abgerufen, "
                                f"{import_result['imported']} importiert, "
                                f"{import_result['matched']} zugeordnet", metadata={
                            k: v for k, v in import_result.items() if k != 'unassigned'})
            messages.success(request, f"Bankabruf abgeschlossen: {import_result['abgerufen']} Umsätze, "
                                      f"{import_result['imported']} neu importiert, "
                                      f"{import_result['matched']} zugeordnet, "
                                      f"{import_result['unclear']} unklar.")
        except BankingError as e:
            messages.error(request, str(e))
        except Exception as e:
            logger.exception('FinTS-Abruf fehlgeschlagen')
            messages.error(request, f'Bankabruf fehlgeschlagen: {e}')
    elif request.method == 'POST' and request.FILES.get('file'):
        try:
            payload = json.loads(request.FILES['file'].read().decode('utf-8-sig'))
            import_result = import_bank_json(payload)
            write_audit(request, 'import', object_type='Bankimport', object_repr='Bank-JSON', message=f"Bankimport: {import_result['imported']} importiert, {import_result['matched']} zugeordnet", metadata=import_result)
            messages.success(request, f"Bankimport abgeschlossen: {import_result['imported']} importiert, {import_result['matched']} zugeordnet, {import_result['unclear']} unklar, {import_result['ignored']} ignoriert.")
        except Exception as e:
            logger.exception('Bank-JSON-Import fehlgeschlagen')
            messages.error(request, f'Bank-JSON konnte nicht importiert werden: {e}')
    payments = Payment.objects.select_related('invoice', 'invoice__customer').all()[:MAX_PAYMENTS_LIST]
    open_invoices = Invoice.objects.exclude(status__in=['bezahlt','storniert']).select_related('customer','obj').prefetch_related('payments')[:200]
    return render(request, 'sedo/payment_list.html', {
        'payments': payments,
        'open_invoices': open_invoices,
        'form': BankJsonImportForm(),
        'import_result': import_result,
        'banking_configured': banking_is_configured(),
        'banking_pin_stored': bool(AppSetting.get('fints_pin', '')),
    })


@login_required
def payment_assign(request, pk):
    payment = get_object_or_404(Payment, pk=pk)
    if request.method == 'POST':
        form = ManualPaymentAssignForm(request.POST)
        if form.is_valid():
            inv = form.cleaned_data['invoice']
            old_invoice = payment.invoice
            payment.invoice = inv
            payment.matched_automatically = False
            payment.save(update_fields=['invoice','matched_automatically','updated_at'])
            write_audit(request, 'payment', payment, f'Zahlung manuell {inv.number} zugeordnet')
            if old_invoice:
                refresh_invoice_payment_status(old_invoice)
            refresh_invoice_payment_status(inv)
            messages.success(request, f'Zahlung wurde {inv.number} zugeordnet.')
            return redirect('sedo:payment_list')
    else:
        form = ManualPaymentAssignForm()
    return render(request, 'sedo/payment_assign.html', {'payment': payment, 'form': form})


@login_required
def payment_delete(request, pk):
    payment = get_object_or_404(Payment, pk=pk)
    invoice = payment.invoice
    if request.method == 'POST':
        write_audit(request, 'delete', payment, 'Zahlung als gelöscht markiert (GoBD-Soft-Delete)')
        # GoBD: Zahlungen werden nur ausgeblendet, nicht hart entfernt.
        payment.soft_delete()
        if invoice:
            refresh_invoice_payment_status(invoice)
        messages.success(request, 'Zahlung wurde ausgeblendet. Der Datensatz bleibt erhalten (GoBD).')
        return redirect('sedo:payment_list')
    return render(request, 'sedo/confirm_delete.html', {'title': 'Zahlung ausblenden', 'text': 'Diese Zahlung wirklich ausblenden? Der Datensatz bleibt GoBD-konform erhalten.', 'cancel_url': reverse('sedo:payment_list')})


@login_required
@require_POST
def invoice_reminder(request, pk, kind):
    invoice = get_object_or_404(Invoice, pk=pk)
    if kind not in ['reminder','dunning']:
        kind = 'reminder'
    # Sperre gegen Mehrfach-Mahnung derselben Stufe – ensure_* fängt den
    # sequenziellen Fall, der Unique-Constraint (via WorkflowError aus
    # generate_dunning_document) den parallelen.
    try:
        ensure_dunning_allowed(invoice, kind)
        doc = generate_dunning_document(invoice, kind)
    except WorkflowError as e:
        messages.error(request, str(e))
        return redirect('sedo:invoice_detail', invoice.pk)
    write_audit(request, 'generate', doc, f'{doc.get_kind_display()} zu {invoice.number} erzeugt')
    messages.success(request, f'{doc.get_kind_display()} wurde erzeugt.')
    return redirect('sedo:invoice_detail', invoice.pk)


@login_required
def cashbook_list(request):
    month = request.GET.get('month') or timezone.localdate().strftime('%Y-%m')
    entries = CashbookEntry.objects.filter(month=month).order_by('booking_no')
    income_total = _sum_decimal(entries.filter(kind='income'), 'amount')
    expense_total = _sum_decimal(entries.filter(kind__in=['expense', 'correction']), 'amount')
    return render(request, 'sedo/cashbook_list.html', {
        'month': month,
        'entries': entries,
        'income_total': income_total,
        'expense_total': expense_total,
        'saldo': income_total - expense_total,
    })


@login_required
def cashbook_create(request, kind):
    if kind not in ['income','expense']:
        kind = 'income'
    today = timezone.localdate()
    first_this_month = today.replace(day=1)
    last_prev = first_this_month - timedelta(days=1)
    while last_prev.weekday() >= 5:
        last_prev -= timedelta(days=1)
    if request.method == 'POST':
        form = CashbookEntryForm(request.POST)
        if form.is_valid():
            e = form.save(commit=False)
            e.kind = kind
            e.month = e.booking_date.strftime('%Y-%m')
            e.booking_no = next_cashbook_no(e.month)
            e.save()
            write_audit(request, 'create', e, 'Kassenbuchung gespeichert')
            messages.success(request, 'Kassenbuchung gespeichert.')
            return redirect(f"{reverse('sedo:cashbook_list')}?month={e.month}")
    else:
        month = last_prev.strftime('%Y-%m')
        form = CashbookEntryForm(initial={'booking_date': last_prev, 'booking_no': next_cashbook_no(month)})
    return render(request, 'sedo/cashbook_form.html', {'form': form, 'kind': kind, 'title': 'Neue Einnahme' if kind == 'income' else 'Neue Ausgabe'})


@login_required
def cashbook_import_bank(request):
    if request.method == 'POST' and request.FILES.get('file'):
        try:
            payload = json.loads(request.FILES['file'].read().decode('utf-8-sig'))
            if isinstance(payload, dict):
                payload = payload.get('transactions') or payload.get('data') or []
            imported = 0
            for t in payload:
                amount = Decimal(str(t.get('betrag', t.get('amount', '0')))).quantize(Decimal('0.01'))
                purpose = str(t.get('verwendungszweck') or t.get('purpose') or '')
                text = (purpose + ' ' + str(t.get('typ',''))).lower()
                if amount < 0 and any(k in text for k in ['bargeld','geldautomat','atm','barabhebung','auszahlung']):
                    booking_date = parse_date_for_view(t.get('datum') or t.get('date'))
                    month = booking_date.strftime('%Y-%m')
                    CashbookEntry.objects.create(month=month, booking_no=next_cashbook_no(month), receipt_no=str(t.get('belegnummer') or t.get('receipt_no') or ''), booking_date=booking_date, kind='income', name='Bargeldabhebung Bank', text=purpose or 'Bargeldabhebung', amount=abs(amount))
                    imported += 1
            write_audit(request, 'import', object_type='Kassenbuch', object_repr='Bankimport', message=f'{imported} Bargeldabhebungen übernommen')
            messages.success(request, f'{imported} Bargeldabhebungen ins Kassenbuch übernommen.')
        except Exception as e:
            logger.exception('Kassenbuch-Bankimport fehlgeschlagen')
            messages.error(request, f'Bankimport Kassenbuch fehlgeschlagen: {e}')
    return redirect('sedo:cashbook_list')


def parse_date_for_view(value):
    """Parst ein Datum aus dem Request robust; fällt auf heute zurück."""
    if isinstance(value, date):
        return value
    s = str(value or '').strip()
    for fmt in ['%Y-%m-%d', '%d.%m.%Y', '%Y%m%d']:
        try:
            return datetime.strptime(s[:10] if fmt == '%Y-%m-%d' else s, fmt).date()
        except ValueError:
            continue
    return timezone.localdate()


@login_required
def cashbook_pdf(request):
    month = request.GET.get('month') or timezone.localdate().strftime('%Y-%m')
    path = generate_cashbook_pdf(month)
    if not path.exists():
        messages.error(request, 'Die Kassenbuch-PDF konnte nicht erzeugt werden.')
        return redirect(f"{reverse('sedo:cashbook_list')}?month={month}")
    return FileResponse(open(path, 'rb'), content_type='application/pdf', filename=path.name)



def _clean_excel_value(value):
    if value is None:
        return ''
    try:
        if pd.isna(value):
            return ''
    except Exception:
        pass
    txt = str(value).strip()
    if txt.endswith('.0') and txt[:-2].isdigit():
        return txt[:-2]
    return txt



def _monthly_zip_email(invoices, customer, month):
    """Erzeugt einen E-Mail-Entwurf mit einem ZIP aller Monatsrechnungen."""
    out_dir = Path(settings.MEDIA_ROOT) / 'monthly_emails'
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_month = str(month or timezone.localdate().strftime('%Y-%m')).replace('/', '-').replace(' ', '_')
    zip_path = out_dir / f'Monatsrechnungen_{safe_month}.zip'
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for inv in invoices:
            if not inv.zugferd_file:
                continue
            p = Path(inv.zugferd_file.path)
            if p.exists():
                zf.write(p, arcname=p.name)
    msg = EmailMessage()
    msg['To'] = customer.email or ''
    msg['From'] = 'info@sedo-magdeburg.de'
    msg['Subject'] = f'Monatsrechnungen {safe_month} - SEDO Objektdienstleistungen'
    body = (
        f'Sehr geehrte Damen und Herren,\n\n'
        f'anbei übersenden wir Ihnen die Monatsrechnungen für {safe_month} als ZIP-Datei.\n'
        f'Enthaltene Rechnungen: {len(invoices)}\n\n'
        f'Mit freundlichen Grüßen\nSEDO Objektdienstleistungen GmbH\n'
    )
    msg.set_content(body)
    if zip_path.exists():
        msg.add_attachment(zip_path.read_bytes(), maintype='application', subtype='zip', filename=zip_path.name)
    eml_path = out_dir / f'Monatsrechnungen_{safe_month}.eml'
    eml_path.write_bytes(msg.as_bytes())
    return eml_path

def _read_aareon_mapping_dataframe(file):
    """Liest die echte GWG-Mappingdatei robust ein.

    Die Kundendatei hat häufig zwei Kopfzeilen:
    Zeile 1: Objektfeld / Ausgangsfeld
    Zeile 2: Rechnungssteller Abrechnungseinheit / Leistungsart-ID / ...
    Darum wird zuerst header=1 versucht. Falls das nicht passt, fällt der Import auf header=0 zurück.
    """
    def normalize_columns(df):
        df = df.copy()
        df.columns = [str(c).strip() for c in df.columns]
        return df

    # Datei ggf. mehrfach lesbar machen
    try:
        file.seek(0)
    except Exception:
        pass
    df = normalize_columns(pd.read_excel(file, sheet_name=0, header=1, dtype=object))
    needed = {'Rechnungssteller Abrechnungseinheit', 'Leistungsart-ID'}
    if not needed.issubset(set(df.columns)):
        try:
            file.seek(0)
        except Exception:
            pass
        df0 = normalize_columns(pd.read_excel(file, sheet_name=0, header=0, dtype=object))
        if needed.issubset(set(df0.columns)):
            df = df0
        else:
            # Sonderfall: erste Datenzeile enthält die echten Header
            for i in range(min(5, len(df0))):
                possible = [_clean_excel_value(v) for v in df0.iloc[i].tolist()]
                if 'Rechnungssteller Abrechnungseinheit' in possible and 'Leistungsart-ID' in possible:
                    df = df0.iloc[i+1:].copy()
                    df.columns = possible
                    break
    return df


def _month_bounds(month_str):
    year, month = [int(x) for x in month_str.split('-')]
    start = date(year, month, 1)
    if month == 12:
        end = date(year, 12, 31)
    else:
        end = date(year, month + 1, 1) - timedelta(days=1)
    return start, end


def _selected_monthly_services(request):
    services = []
    for sid in ['Reinigung', 'Winterdienst', 'Heckenschnitt']:
        if request.POST.get(f'use_{sid}'):
            try:
                qty = Decimal(str(request.POST.get(f'qty_{sid}') or '1').replace(',', '.')).quantize(Decimal('0.01'))
            except Exception:
                qty = Decimal('1.00')
            try:
                price = Decimal(str(request.POST.get(f'price_{sid}') or '10').replace(',', '.')).quantize(Decimal('0.01'))
            except Exception:
                price = Decimal('10.00')
            desc = request.POST.get(f'desc_{sid}') or sid
            unit = request.POST.get(f'unit_{sid}') or 'Stk.'
            services.append({'id': sid, 'description': desc, 'quantity': qty, 'unit': unit, 'unit_price': price})
    return services

def _perform_aareon_mapping_import(df, request):
    """Importiert einen bereits gelesenen DataFrame als AareonMapping-Einträge.

    Ersetzt den Mapping-Bestand **transaktional**: Löschen und Neuanlage laufen
    in EINER Transaktion – schlägt irgendetwas mitten im Import fehl, wird alles
    zurückgerollt und der alte Bestand bleibt vollständig erhalten (vorher
    konnte ein Fehler nach dem Löschen den kompletten Bestand kosten).
    Wirft bei ungültigen Spalten eine ValueError-Exception (vor dem Löschen).
    """
    required = ['Rechnungssteller Abrechnungseinheit', 'Leistungsart-ID']
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError('Pflichtspalten fehlen: ' + ', '.join(missing) + '. Erwartet wird die GWG-Mappingdatei mit der Fachkopfzeile in Zeile 2.')
    # Zeilen erst im Speicher sammeln (letzter Eintrag je Einheit+Leistung
    # gewinnt – wie vorher bei update_or_create), dann EIN bulk_create statt
    # hunderter Einzel-Queries (Audit-Empfehlung 15.08.). Der Bestand wurde
    # zuvor gelöscht, Kollisionen mit Altdaten gibt es daher nicht.
    rows: dict[tuple, AareonMapping] = {}
    for _, row in df.iterrows():
        bu = _clean_excel_value(row.get('Rechnungssteller Abrechnungseinheit'))
        sid = _clean_excel_value(row.get('Leistungsart-ID'))
        if not bu or not sid:
            continue
        valid_from = None
        raw_date = row.get('gültig ab') if 'gültig ab' in df.columns else row.get('gueltig ab') if 'gueltig ab' in df.columns else None
        try:
            if hasattr(raw_date, 'date'):
                valid_from = raw_date.date()
            elif raw_date:
                valid_from = pd.to_datetime(raw_date).date()
        except (ValueError, TypeError):
            valid_from = None
        rows[(bu, sid)] = AareonMapping(
            billing_unit_sender=bu,
            service_id=sid,
            company_code=_clean_excel_value(row.get('Buchungskreis')),
            erp_contract_no=_clean_excel_value(row.get('ERP-Vertragsnummer')),
            we_internal=_clean_excel_value(row.get('Wirtschaftseinheit')),
            ae_internal=_clean_excel_value(row.get('Abrechnungseinheit')),
            nksl_internal=_clean_excel_value(row.get('Nebenkostenschlüssel')),
            account=_clean_excel_value(row.get('Sachkonto')),
            valid_from=valid_from,
        )
    with transaction.atomic():
        AareonMapping.objects.all().delete()
        AareonMapping.objects.bulk_create(rows.values())
    count = len(rows)
    stats = {
        'count': count,
        'units': AareonMapping.objects.values('billing_unit_sender').distinct().count(),
        'services': AareonMapping.objects.values('service_id').distinct().count(),
    }
    if count:
        write_audit(request, 'import', object_type='AareonMapping', object_repr='GWG Mapping', message=f'{count} Mapping-Zeilen importiert')
        messages.success(request, f'{count} Mapping-Zeilen importiert. Daraus können jetzt GWG-Monatsrechnungen erzeugt werden.')
    else:
        messages.error(request, '0 Zeilen importiert. Bitte prüfen, ob die Datei die Spalten „Rechnungssteller Abrechnungseinheit" und „Leistungsart-ID" enthält.')
    return stats


@login_required
def aareon_import(request):
    """Monatsrechnung/GWG: Mapping importieren und monatliche Rechnungen erzeugen."""
    stats = None
    run_result = None
    today = timezone.localdate()
    default_month = f"{today.year}-{today.month:02d}"
    generated_invoice_ids = request.session.get('last_monthly_invoice_ids', [])
    generated_invoices = Invoice.objects.filter(id__in=generated_invoice_ids).select_related('customer','obj').order_by('number') if generated_invoice_ids else []

    if request.method == 'POST':
        action = request.POST.get('action') or 'import'

        if action == 'import':
            if not request.FILES.get('file'):
                messages.error(request, 'Bitte eine Mapping-Datei auswählen.')
            else:
                file = request.FILES['file']
                try:
                    df = _read_aareon_mapping_dataframe(file)
                    stats = _perform_aareon_mapping_import(df, request)
                except Exception as e:
                    messages.error(request, f'Mapping-Import fehlgeschlagen: {e}')

        elif action == 'send_monthly_email':
            ids = request.POST.getlist('invoice_ids')
            month = request.POST.get('month') or default_month
            invoices = list(Invoice.objects.filter(id__in=ids).select_related('customer').order_by('number'))
            if not invoices:
                messages.error(request, 'Keine Monatsrechnungen für den Versand ausgewählt.')
            elif len({inv.customer_id for inv in invoices}) > 1:
                # Sicherheitsprüfung: Ein manipulierter/fehlerhafter POST darf
                # keine Rechnungen fremder Kunden in die ZIP eines Empfängers mischen.
                messages.error(request, 'Die ausgewählten Rechnungen gehören zu mehreren Kunden. '
                                        'Bitte nur Rechnungen EINES Empfängers für den Sammelversand auswählen.')
            else:
                customer = invoices[0].customer
                try:
                    eml_path = _monthly_zip_email(invoices, customer, month)
                    return FileResponse(open(eml_path, 'rb'), as_attachment=True, filename=eml_path.name)
                except Exception as e:
                    messages.error(request, f'E-Mail-Entwurf konnte nicht erzeugt werden: {e}')

        elif action == 'generate':
            customer_id = request.POST.get('customer')
            month = request.POST.get('month') or default_month
            issue_date = parse_date_for_view(request.POST.get('issue_date'))
            try:
                payment_days = int(request.POST.get('payment_days') or DEFAULT_PAYMENT_DAYS)
            except (TypeError, ValueError):
                payment_days = DEFAULT_PAYMENT_DAYS
            services = _selected_monthly_services(request)
            skip_existing = bool(request.POST.get('skip_existing'))
            limit_raw = request.POST.get('limit') or ''
            limit = int(limit_raw) if str(limit_raw).isdigit() else None

            if not customer_id:
                messages.error(request, 'Bitte einen Rechnungsempfänger/Kunden auswählen.')
            elif not services:
                messages.error(request, 'Bitte mindestens eine Leistung für den Monatslauf auswählen.')
            elif not AareonMapping.objects.exists():
                messages.error(request, 'Bitte zuerst die Mapping-Datei importieren.')
            else:
                customer = get_object_or_404(Customer, pk=customer_id)
                ps, pe = _month_bounds(month)
                due = issue_date + timedelta(days=payment_days)
                created = skipped = missing = 0
                errors = []
                created_ids = []
                units = list(AareonMapping.objects.values_list('billing_unit_sender', flat=True).distinct().order_by('billing_unit_sender'))
                if limit:
                    units = units[:limit]
                # Mapping einmalig indexieren statt pro Einheit × Leistung neu abzufragen (kein N+1).
                mapping_index = {
                    (m.billing_unit_sender, m.service_id): m
                    for m in AareonMapping.objects.all()
                }
                for unit_name in units:
                    if skip_existing and Invoice.objects.filter(customer=customer, obj__name=unit_name, source='GWG Monatsrechnung', period_start=ps, period_end=pe).exclude(status='storniert').exists():
                        skipped += 1
                        continue
                    # Erst prüfen, welche Leistungen gemappt sind – erst dann eine Nummer
                    # vergeben, damit keine Rechnungsnummern „verbrannt“ werden.
                    matched = []
                    for svc in services:
                        mapping = mapping_index.get((unit_name, svc['id']))
                        if mapping:
                            matched.append((svc, mapping))
                        else:
                            missing += 1
                    if not matched:
                        continue
                    # Jede Einheit läuft in EINER Transaktion: schlägt irgendetwas
                    # (auch die PDF-/XML-Erzeugung) fehl, wird die komplette
                    # Rechnung zurückgerollt – keine Teilrechnungen in der DB.
                    try:
                        with transaction.atomic():
                            obj, _ = CustomerObject.objects.get_or_create(
                                customer=customer,
                                name=unit_name,
                                defaults={'street': unit_name, 'postcode': customer.postcode, 'city': customer.city, 'country': customer.country or 'DE'}
                            )
                            inv = create_numbered_invoice(
                                invoice_type='380',
                                customer=customer,
                                obj=obj,
                                issue_date=issue_date,
                                due_date=due,
                                period_start=ps,
                                period_end=pe,
                                vat_rate=Decimal('19.00'),
                                status='erstellt',
                                source='GWG Monatsrechnung',
                                note=f'Monatsrechnung {month} auf Basis GWG-Mapping.',
                            )
                            for pos_no, (svc, mapping) in enumerate(matched, start=1):
                                InvoiceItem.objects.create(
                                    invoice=inv,
                                    position=pos_no,
                                    description=svc['description'],
                                    quantity=svc['quantity'],
                                    unit=svc['unit'],
                                    unit_price=svc['unit_price'],
                                    article_no=mapping.nksl_internal,
                                    leistungsart_id=mapping.service_id,
                                    leistungsart_text=mapping.service_id,
                                )
                            recalc_invoice(inv)
                            inv.save()
                            generate_invoice_files(inv)
                        created += 1
                        created_ids.append(inv.id)
                    except IntegrityError:
                        # Idempotenz-Schutz (Unique-Constraint) hat gegriffen:
                        # dieselbe Monatsrechnung existiert bereits – z. B. bei
                        # doppelt/parallel gestartetem Lauf. Kein Fehler.
                        logger.info('GWG-Monatslauf: Einheit %s existiert bereits (übersprungen)', unit_name)
                        skipped += 1
                    except Exception as e:
                        logger.exception('GWG-Monatslauf: Einheit %s fehlgeschlagen', unit_name)
                        errors.append(f'{unit_name}: {e}')
                request.session['last_monthly_invoice_ids'] = created_ids
                generated_invoice_ids = created_ids
                generated_invoices = Invoice.objects.filter(id__in=created_ids).select_related('customer','obj').order_by('number') if created_ids else []
                run_result = {'created': created, 'skipped': skipped, 'missing': missing, 'errors': errors[:20], 'month': month, 'invoice_ids': created_ids}
                if created:
                    messages.success(request, f'{created} Monatsrechnungen erzeugt. {skipped} übersprungen. Fehlende Leistungszuordnungen: {missing}.')
                else:
                    messages.warning(request, f'Keine Monatsrechnungen erzeugt. {skipped} übersprungen. Fehlende Leistungszuordnungen: {missing}.')

    context = {
        'stats': stats,
        'run_result': run_result,
        'mappings': AareonMapping.objects.all()[:100],
        'mapping_count': AareonMapping.objects.count(),
        'unit_count': AareonMapping.objects.values('billing_unit_sender').distinct().count(),
        'customers': Customer.objects.all(),
        'default_month': default_month,
        'default_issue_date': today.isoformat(),
        'generated_invoices': generated_invoices,
        'recurring_templates': RecurringInvoiceTemplate.objects.select_related('customer','obj').prefetch_related('items').all(),
        'last_recurring_invoices': Invoice.objects.filter(id__in=request.session.get('last_recurring_invoice_ids', [])).select_related('customer','obj').order_by('number') if request.session.get('last_recurring_invoice_ids') else [],
    }
    return render(request, 'sedo/aareon_monthly.html', context)



@login_required
def recurring_monthly(request):
    today = timezone.localdate()
    default_month = f"{today.year}-{today.month:02d}"
    context = {
        'default_month': default_month,
        'default_issue_date': today.isoformat(),
        'recurring_templates': RecurringInvoiceTemplate.objects.select_related('customer','obj').prefetch_related('items').all(),
        'last_recurring_invoices': Invoice.objects.filter(id__in=request.session.get('last_recurring_invoice_ids', [])).select_related('customer','obj').order_by('number') if request.session.get('last_recurring_invoice_ids') else [],
    }
    return render(request, 'sedo/recurring_monthly.html', context)


@login_required
def aareon_legacy_redirect(request):
    return redirect('sedo:aareon_monthly')


@login_required
def recurring_template_create(request):
    instance = RecurringInvoiceTemplate()
    if request.method == 'POST':
        form = RecurringInvoiceTemplateForm(request.POST, instance=instance)
        formset = RecurringInvoiceItemFormSet(request.POST, instance=instance)
        if form.is_valid() and formset.is_valid():
            tmpl = form.save()
            formset.instance = tmpl
            formset.save()
            _normalize_item_positions(tmpl.items.all())
            messages.success(request, 'Abo-/Monatsrechnungsvorlage gespeichert.')
            return redirect('sedo:recurring_monthly')
    else:
        form = RecurringInvoiceTemplateForm(instance=instance)
        formset = RecurringInvoiceItemFormSet(instance=instance, queryset=RecurringInvoiceItem.objects.none())
    return render(request, 'sedo/recurring_template_form.html', {'form': form, 'formset': formset, 'title': 'Abo-/Monatsrechnung anlegen'})


@login_required
def recurring_template_update(request, pk):
    tmpl = get_object_or_404(RecurringInvoiceTemplate, pk=pk)
    if request.method == 'POST':
        form = RecurringInvoiceTemplateForm(request.POST, instance=tmpl)
        formset = RecurringInvoiceItemFormSet(request.POST, instance=tmpl)
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            _normalize_item_positions(tmpl.items.all())
            messages.success(request, 'Abo-/Monatsrechnungsvorlage aktualisiert.')
            return redirect('sedo:recurring_monthly')
    else:
        form = RecurringInvoiceTemplateForm(instance=tmpl)
        formset = RecurringInvoiceItemFormSet(instance=tmpl)
    return render(request, 'sedo/recurring_template_form.html', {'form': form, 'formset': formset, 'title': 'Abo-/Monatsrechnung bearbeiten'})


@login_required
def recurring_template_delete(request, pk):
    tmpl = get_object_or_404(RecurringInvoiceTemplate, pk=pk)
    if request.method == 'POST':
        tmpl.delete()
        messages.success(request, 'Abo-/Monatsrechnungsvorlage gelöscht.')
        return redirect('sedo:recurring_monthly')
    return render(request, 'sedo/confirm_delete.html', {'title':'Abo-/Monatsrechnung löschen', 'text':f'Vorlage „{tmpl.title}“ wirklich löschen?', 'cancel_url': reverse('sedo:recurring_monthly')})


def _generate_recurring_invoice_from_template(tmpl, issue_date, period_start, period_end, due_date):
    """Erzeugt eine Abo-Monatsrechnung – atomar: Fehler (auch bei PDF/XML)
    rollen die komplette Rechnung zurück, keine Teilrechnungen."""
    with transaction.atomic():
        return _generate_recurring_invoice_inner(tmpl, issue_date, period_start, period_end, due_date)


def _generate_recurring_invoice_inner(tmpl, issue_date, period_start, period_end, due_date):
    inv = create_numbered_invoice(
        invoice_type='380',
        customer=tmpl.customer,
        obj=tmpl.obj,
        issue_date=issue_date,
        due_date=due_date,
        period_start=period_start,
        period_end=period_end,
        vat_rate=tmpl.vat_rate,
        status='erstellt',
        source='Abo Monatsrechnung',
        note=tmpl.note or f'Monatsrechnung auf Basis der Vorlage „{tmpl.title}“.',
    )
    for idx, item in enumerate(tmpl.items.all(), start=1):
        InvoiceItem.objects.create(
            invoice=inv,
            position=idx,
            description=item.description,
            long_text=item.long_text,
            quantity=item.quantity,
            unit=item.unit,
            unit_price=item.unit_price,
            article_no=item.article_no,
        )
    recalc_invoice(inv)
    inv.save()
    generate_invoice_files(inv)
    return inv


@login_required
def recurring_monthly_generate(request):
    if request.method != 'POST':
        return redirect('sedo:recurring_monthly')
    month = request.POST.get('month') or f"{timezone.localdate().year}-{timezone.localdate().month:02d}"
    issue_date = parse_date_for_view(request.POST.get('issue_date'))
    skip_existing = bool(request.POST.get('skip_existing'))
    selected_ids = request.POST.getlist('template_ids')
    if selected_ids:
        templates = RecurringInvoiceTemplate.objects.filter(id__in=selected_ids, status='active').select_related('customer','obj')
    else:
        templates = RecurringInvoiceTemplate.objects.filter(status='active').select_related('customer','obj')
    ps, pe = _month_bounds(month)
    created_ids = []
    skipped = 0
    failed = []
    for tmpl in templates:
        if skip_existing and Invoice.objects.filter(customer=tmpl.customer, obj=tmpl.obj, source='Abo Monatsrechnung', period_start=ps, period_end=pe).exclude(status='storniert').exists():
            skipped += 1
            continue
        due = issue_date + timedelta(days=tmpl.payment_days or tmpl.customer.payment_days or DEFAULT_PAYMENT_DAYS)
        try:
            inv = _generate_recurring_invoice_from_template(tmpl, issue_date, ps, pe, due)
            created_ids.append(inv.id)
        except Exception:
            # Eine fehlgeschlagene Vorlage bricht nicht den ganzen Lauf ab;
            # die Rechnung wurde durch die Transaktion vollständig zurückgerollt.
            logger.exception('Abo-Monatslauf: Vorlage „%s“ fehlgeschlagen', tmpl.title)
            failed.append(tmpl.title)
    request.session['last_recurring_invoice_ids'] = created_ids
    if created_ids:
        messages.success(request, f'{len(created_ids)} normale Monatsrechnungen erzeugt. {skipped} übersprungen.')
    else:
        messages.warning(request, f'Keine normalen Monatsrechnungen erzeugt. {skipped} übersprungen.')
    if failed:
        messages.error(request, 'Fehlgeschlagen (vollständig zurückgerollt): ' + ', '.join(failed[:5]))
    return redirect('sedo:recurring_monthly')

@login_required
def settings_page(request):
    stats = None
    if request.method == 'POST':
        action = request.POST.get('action') or 'save_settings'

        if action == 'import_mapping':
            if not request.FILES.get('file'):
                messages.error(request, 'Bitte eine Mapping-Datei auswählen.')
            else:
                file = request.FILES['file']
                try:
                    df = _read_aareon_mapping_dataframe(file)
                    stats = _perform_aareon_mapping_import(df, request)
                except Exception as e:
                    messages.error(request, f'Mapping-Import fehlgeschlagen: {e}')
            return redirect('sedo:settings')

        if action == 'save_ai':
            # API-Key nur speichern, wenn neu eingegeben (leer = unverändert)
            new_key = request.POST.get('ai_api_key', '').strip()
            if request.POST.get('ai_api_key_clear'):
                AppSetting.set('ai_api_key', '')
            elif new_key:
                AppSetting.set('ai_api_key', new_key)
            AppSetting.set('ai_text_model', request.POST.get('ai_text_model', '').strip())
            write_audit(request, 'update', object_type='AppSetting', object_repr='KI-Assistent',
                        message='KI-Einstellungen gespeichert')
            messages.success(request, 'KI-Einstellungen gespeichert.')
            return redirect('sedo:settings')

        if action == 'save_smtp':
            AppSetting.set('smtp_host',      request.POST.get('smtp_host', '').strip())
            AppSetting.set('smtp_port',      request.POST.get('smtp_port', '587').strip() or '587')
            AppSetting.set('smtp_user',      request.POST.get('smtp_user', '').strip())
            AppSetting.set('smtp_from_name', request.POST.get('smtp_from_name', '').strip())
            AppSetting.set('smtp_tls',       '1' if request.POST.get('smtp_tls') else '0')
            # Passwort nur speichern wenn neu eingegeben (leeres Feld = unverändert lassen)
            new_pw = request.POST.get('smtp_password', '')
            if new_pw:
                AppSetting.set('smtp_password', new_pw)
            write_audit(request, 'update', object_type='AppSetting', object_repr='SMTP',
                        message='SMTP-Einstellungen gespeichert')
            messages.success(request, 'SMTP-Einstellungen gespeichert.')
            return redirect('sedo:settings')

        if action == 'save_banking':
            AppSetting.set('fints_blz',        request.POST.get('fints_blz', '').strip())
            AppSetting.set('fints_endpoint',   request.POST.get('fints_endpoint', '').strip())
            AppSetting.set('fints_login',      request.POST.get('fints_login', '').strip())
            AppSetting.set('fints_iban',       request.POST.get('fints_iban', '').replace(' ', '').strip())
            AppSetting.set('fints_product_id', request.POST.get('fints_product_id', '').strip())
            # PIN nur speichern, wenn neu eingegeben; Löschen per Checkbox.
            # (Wie ai_api_key/smtp_password: aus Backups bereinigt, Env hat Vorrang.)
            if request.POST.get('fints_pin_clear'):
                AppSetting.set('fints_pin', '')
            elif request.POST.get('fints_pin', ''):
                AppSetting.set('fints_pin', request.POST.get('fints_pin', ''))
            write_audit(request, 'update', object_type='AppSetting', object_repr='Bankkonto',
                        message='FinTS-Bankzugang gespeichert')
            messages.success(request, 'Bankzugang gespeichert.')
            return redirect('sedo:settings')

        if action == 'test_smtp':
            test_to = request.POST.get('test_email', '').strip()
            if not test_to:
                messages.error(request, 'Bitte eine Ziel-E-Mail-Adresse für den Test eingeben.')
            else:
                try:
                    send_email_smtp(
                        test_to,
                        'SEDO – SMTP-Verbindungstest',
                        'Diese E-Mail bestätigt, dass der SMTP-Versand aus SEDO korrekt konfiguriert ist.',
                    )
                    write_audit(request, 'generate', object_type='SMTP', object_repr='Test',
                                message=f'Test-E-Mail an {test_to} versendet')
                    messages.success(request, f'Test-E-Mail erfolgreich an {test_to} versendet.')
                except Exception as e:
                    messages.error(request, f'SMTP-Test fehlgeschlagen: {e}')
            return redirect('sedo:settings')

        AppSetting.set('aareon_seller_id', request.POST.get('aareon_seller_id', ''))
        AppSetting.set('aareon_include_seller_assigned_id', '1' if request.POST.get('aareon_include_seller_assigned_id') else '0')
        write_audit(request, 'update', object_type='AppSetting', object_repr='Einstellungen', message='Systemeinstellungen gespeichert')
        messages.success(request, 'Einstellungen wurden gespeichert.')
        return redirect('sedo:settings')

    smtp_cfg = get_smtp_config()
    context = {
        'aareon_seller_id': AppSetting.get('aareon_seller_id', ''),
        'aareon_include_seller_assigned_id': AppSetting.get('aareon_include_seller_assigned_id', '0'),
        'mapping_count': AareonMapping.objects.count(),
        'unit_count': AareonMapping.objects.values('billing_unit_sender').distinct().count(),
        'service_count': AareonMapping.objects.values('service_id').distinct().count(),
        'mappings': AareonMapping.objects.all()[:50],
        'stats': stats,
        'smtp_host':      smtp_cfg['host'],
        'smtp_port':      smtp_cfg['port'],
        'smtp_user':      smtp_cfg['user'],
        'smtp_from_name': smtp_cfg['from_name'],
        'smtp_tls':       smtp_cfg['tls'],
        'smtp_configured': smtp_is_configured(),
        'banking_cfg': get_banking_config(),
        'banking_configured': banking_is_configured(),
        'banking_pin_stored': bool(AppSetting.get('fints_pin', '')),
    }
    return render(request, 'sedo/settings.html', context)

@login_required
def month_close(request):
    """Monatsabschluss: Steuerberater-Export."""
    today = timezone.localdate()
    default_month = today.strftime('%Y-%m')
    selected_month = request.POST.get('month') or request.GET.get('month') or default_month
    tax_email = request.POST.get('tax_email') or AppSetting.get('tax_advisor_email', '')

    try:
        year, month = [int(x) for x in selected_month.split('-')[:2]]
    except (ValueError, AttributeError):
        year, month = today.year, today.month
        selected_month = f'{year:04d}-{month:02d}'

    invoices = Invoice.objects.filter(issue_date__year=year, issue_date__month=month).select_related('customer','obj').prefetch_related('items').order_by('number')

    if request.method == 'POST':
        action = request.POST.get('action')
        if tax_email:
            AppSetting.set('tax_advisor_email', tax_email)
        if action == 'export_tax_email':
            out_dir = Path(settings.MEDIA_ROOT) / 'month_close' / selected_month
            out_dir.mkdir(parents=True, exist_ok=True)
            zip_path = out_dir / f'SEDO_Rechnungen_{selected_month}_Steuerberater_PDF.zip'
            pdf_count = 0
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.writestr('README.txt', f'SEDO PDF-Rechnungsexport fuer {selected_month}\nEnthalten sind ausschliesslich die sichtbaren Rechnungs-PDFs.\n')
                for inv in invoices:
                    generate_invoice_files(inv)
                    filefield = inv.pdf_file
                    if filefield and getattr(filefield, 'path', None):
                        p = Path(filefield.path)
                        if p.exists():
                            safe_name = f'{inv.number}_{p.name}' if not p.name.startswith(str(inv.number)) else p.name
                            zf.write(p, arcname=safe_name)
                            pdf_count += 1
            msg = EmailMessage()
            msg['To'] = tax_email or ''
            msg['From'] = 'info@sedo-magdeburg.de'
            msg['Subject'] = f'SEDO Rechnungsexport {selected_month}'
            msg.set_content(
                f'Sehr geehrte Damen und Herren,\n\n'
                f'anbei erhalten Sie die Rechnungs-PDFs für {selected_month}.\n'
                f'Enthaltene PDF-Rechnungen: {pdf_count}\n\n'
                f'Mit freundlichen Grüßen\nSEDO Objektdienstleistungen GmbH\n'
            )
            msg.add_attachment(zip_path.read_bytes(), maintype='application', subtype='zip', filename=zip_path.name)
            eml_path = out_dir / f'SEDO_Rechnungsexport_{selected_month}.eml'
            eml_path.write_bytes(msg.as_bytes())
            return FileResponse(open(eml_path, 'rb'), as_attachment=True, filename=eml_path.name)

    context = {
        'selected_month': selected_month,
        'tax_email': tax_email,
        'invoices': invoices,
        'invoice_count': invoices.count(),
        'gross_total': _sum_decimal(invoices, 'gross_total'),
    }
    return render(request, 'sedo/month_close.html', context)

@login_required
def backup_page(request):
    """Systembereich: Backup verwalten."""
    from .backup_utils import create_backup
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'backup_now':
            backup_file = create_backup('manual_system')
            write_audit(request, 'backup', object_type='Backup', object_repr=backup_file.name, message='Manuelles Backup erstellt')
            messages.success(request, f'Backup erstellt: {backup_file.name}')
        elif action == 'disable_weekly':
            AppSetting.set('auto_weekly_backup_enabled', '0')
            write_audit(request, 'backup', object_type='Backup', object_repr='Automatisches Wochenbackup', message='Automatisches Wochenbackup deaktiviert')
            messages.success(request, 'Automatisches Wochenbackup wurde deaktiviert.')
        elif action == 'enable_weekly':
            AppSetting.set('auto_weekly_backup_enabled', '1')
            write_audit(request, 'backup', object_type='Backup', object_repr='Automatisches Wochenbackup', message='Automatisches Wochenbackup aktiviert')
            messages.success(request, 'Automatisches Wochenbackup wurde aktiviert.')
        return redirect('sedo:backup')
    context = {
        'auto_weekly_backup_enabled': AppSetting.get('auto_weekly_backup_enabled', '1'),
        'last_backup_at': AppSetting.get('last_backup_at', ''),
        'last_weekly_backup_at': AppSetting.get('last_weekly_backup_at', ''),
        'last_backup_path': AppSetting.get('last_backup_path', ''),
        'last_weekly_backup_path': AppSetting.get('last_weekly_backup_path', ''),
    }
    return render(request, 'sedo/backup.html', context)

@login_required
def security_status(request):
    """Kompakte Sicherheitsübersicht für den Produktivbetrieb."""
    last_backup = AppSetting.get('last_backup_at', '')
    # Nutzt der Admin noch das alte, dokumentierte Standard-Passwort?
    from django.contrib.auth import get_user_model
    admin_user = get_user_model().objects.filter(username='admin').first()
    admin_default_pw = bool(admin_user and admin_user.check_password('sedo1234'))
    checks = [
        {
            'label': 'Admin-Standard-Passwort geändert',
            'ok': not admin_default_pw,
            'value': 'geändert' if not admin_default_pw else 'NOCH "sedo1234"!',
            'hint': 'Die App ist im Heimnetz (0.0.0.0) und ggf. per Tunnel erreichbar – Standard-Passwort ändern: python manage.py changepassword admin',
        },
        {
            'label': 'DEBUG deaktiviert',
            'ok': not settings.DEBUG,
            'value': 'aus' if not settings.DEBUG else 'AN',
            'hint': 'Produktivbetrieb nur mit DEBUG=False.',
        },
        {
            'label': 'Allowed Hosts eingeschränkt',
            'ok': '*' not in getattr(settings, 'ALLOWED_HOSTS', []),
            'value': ', '.join(getattr(settings, 'ALLOWED_HOSTS', [])),
            'hint': 'Keine Wildcard im Produktivbetrieb.',
        },
        {
            'label': 'HTTPS-Redirect aktiv',
            'ok': bool(getattr(settings, 'SECURE_SSL_REDIRECT', False)),
            'value': 'aktiv' if getattr(settings, 'SECURE_SSL_REDIRECT', False) else 'nicht aktiv',
            'hint': 'HTTP sollte auf HTTPS umleiten.',
        },
        {
            'label': 'Sichere Session-Cookies',
            'ok': bool(getattr(settings, 'SESSION_COOKIE_SECURE', False)),
            'value': 'aktiv' if getattr(settings, 'SESSION_COOKIE_SECURE', False) else 'nicht aktiv',
            'hint': 'Session-Cookies nur per HTTPS übertragen.',
        },
        {
            'label': 'Sichere CSRF-Cookies',
            'ok': bool(getattr(settings, 'CSRF_COOKIE_SECURE', False)),
            'value': 'aktiv' if getattr(settings, 'CSRF_COOKIE_SECURE', False) else 'nicht aktiv',
            'hint': 'CSRF-Cookies nur per HTTPS übertragen.',
        },
        {
            'label': 'Clickjacking-Schutz',
            'ok': getattr(settings, 'X_FRAME_OPTIONS', '') == 'DENY',
            'value': getattr(settings, 'X_FRAME_OPTIONS', '—'),
            'hint': 'Einbettung in fremde Frames blockieren.',
        },
        {
            'label': 'HSTS aktiv',
            'ok': int(getattr(settings, 'SECURE_HSTS_SECONDS', 0) or 0) > 0,
            'value': f"{getattr(settings, 'SECURE_HSTS_SECONDS', 0)} Sekunden",
            'hint': 'Für Produktivbetrieb sinnvoll. IncludeSubDomains/Preload erst aktivieren, wenn alle Subdomains geprüft sind.',
        },
        {
            'label': 'Backup vorhanden',
            'ok': bool(last_backup),
            'value': last_backup or 'noch kein Backup vermerkt',
            'hint': 'Vor Bankanbindung täglich und extern sichern.',
        },
        {
            'label': '.env nicht im App-Backup',
            'ok': True,
            'value': 'ausgeschlossen',
            'hint': 'Secrets werden nicht in Benutzer-Backups gepackt.',
        },
    ]
    ok_count = len([c for c in checks if c['ok']])
    recent_logs = AuditLog.objects.select_related('user')[:20]
    context = {
        'checks': checks,
        'ok_count': ok_count,
        'total_count': len(checks),
        'recent_logs': recent_logs,
        'bank_ready': ok_count >= len(checks) - 1,
    }
    return render(request, 'sedo/security_status.html', context)


@login_required
def audit_log_page(request):
    action = request.GET.get('action', '').strip()
    q = request.GET.get('q', '').strip()
    logs = AuditLog.objects.select_related('user').all()
    if action:
        logs = logs.filter(action=action)
    if q:
        logs = logs.filter(Q(object_repr__icontains=q) | Q(message__icontains=q) | Q(user__username__icontains=q) | Q(ip_address__icontains=q))
    return render(request, 'sedo/audit_log.html', {
        'logs': logs[:500],
        'action': action,
        'q': q,
        'actions': AuditLog.ACTIONS,
    })
